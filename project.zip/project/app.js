(() => {
  // js/db.js
  var DB_NAME = "chemfinance";
  var DB_VERSION = 1;
  var STORES = ["profile", "accounts", "transactions", "categories", "budgets", "goals", "assets", "liabilities", "recurring", "scenarios", "snapshots", "settings"];
  var db;
  var mem = null;
  var isTemporary = () => !!mem;
  function openDB() {
    const useMem = () => {
      mem = {};
      STORES.forEach((s) => mem[s] = /* @__PURE__ */ new Map());
      return null;
    };
    return new Promise((resolve) => {
      let req;
      const t = setTimeout(() => resolve(useMem()), 2500);
      try {
        req = indexedDB.open(DB_NAME, DB_VERSION);
      } catch {
        clearTimeout(t);
        return resolve(useMem());
      }
      req.onupgradeneeded = () => {
        const d = req.result;
        STORES.forEach((s) => {
          if (!d.objectStoreNames.contains(s)) d.createObjectStore(s, { keyPath: "id" });
        });
      };
      req.onsuccess = () => {
        clearTimeout(t);
        if (!mem) {
          db = req.result;
          resolve(db);
        }
      };
      req.onerror = () => {
        clearTimeout(t);
        resolve(useMem());
      };
    });
  }
  var tx = (store, mode = "readonly") => db.transaction(store, mode).objectStore(store);
  var wrap = (r) => new Promise((res, rej) => {
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });
  var getAll = (store) => mem ? Promise.resolve([...mem[store].values()]) : wrap(tx(store).getAll());
  var put = (store, obj) => mem ? Promise.resolve(mem[store].set(obj.id, obj)) : wrap(tx(store, "readwrite").put(obj));
  var del = (store, id) => mem ? Promise.resolve(mem[store].delete(id)) : wrap(tx(store, "readwrite").delete(id));
  var clear = (store) => mem ? Promise.resolve(mem[store].clear()) : wrap(tx(store, "readwrite").clear());
  function putMany(store, list) {
    if (mem) {
      list.forEach((o) => mem[store].set(o.id, o));
      return Promise.resolve();
    }
    return new Promise((res, rej) => {
      const t = db.transaction(store, "readwrite");
      list.forEach((o) => t.objectStore(store).put(o));
      t.oncomplete = res;
      t.onerror = () => rej(t.error);
    });
  }
  async function replaceAll(data) {
    for (const s of STORES) {
      await clear(s);
      if (data[s]?.length) await putMany(s, data[s]);
    }
  }
  async function loadAll() {
    const out = {};
    for (const s of STORES) out[s] = await getAll(s);
    return out;
  }

  // js/util.js
  var uid = (p = "id") => p + "_" + Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  var now = () => (/* @__PURE__ */ new Date()).toISOString();
  var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
  var dots = (n) => String(Math.round(Math.abs(n))).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  var rp = (n) => (n < 0 ? "\u2212Rp " : "Rp ") + dots(n);
  var pct = (v, d = 1) => (Number.isFinite(v) ? v.toFixed(d).replace(/\.0+$/, "").replace(".", ",") : "0") + "%";
  var parseAmount = (s) => parseInt(String(s ?? "").replace(/\D/g, ""), 10) || 0;
  var p2 = (n) => String(n).padStart(2, "0");
  var ymd = (d) => `${d.getFullYear()}-${p2(d.getMonth() + 1)}-${p2(d.getDate())}`;
  var today = () => ymd(/* @__PURE__ */ new Date());
  var monthKey = (dateStr) => dateStr.slice(0, 7);
  var curMonth = () => today().slice(0, 7);
  var parseYmd = (s) => {
    const [y, m, d] = s.split("-").map(Number);
    return new Date(y, m - 1, d);
  };
  var validDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && ymd(parseYmd(s)) === s;
  var addMonths = (mk, n) => {
    const [y, m] = mk.split("-").map(Number);
    const d = new Date(y, m - 1 + n, 1);
    return `${d.getFullYear()}-${p2(d.getMonth() + 1)}`;
  };
  var daysInMonth = (mk) => {
    const [y, m] = mk.split("-").map(Number);
    return new Date(y, m, 0).getDate();
  };
  var MONTHS = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  var MON3 = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
  var monthLabel = (mk) => {
    const [y, m] = mk.split("-").map(Number);
    return `${MONTHS[m - 1]} ${y}`;
  };
  var dateLong = (s) => {
    const d = parseYmd(s);
    return `${d.getDate()} ${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
  };
  var dateShort = (s) => {
    const d = parseYmd(s);
    return `${p2(d.getDate())} ${MON3[d.getMonth()]}`;
  };
  var dayName = (s) => ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"][parseYmd(s).getDay()];
  var clampDay = (mk, day) => Math.min(day, daysInMonth(mk));
  var monthsBetween = (a, b) => {
    const [y1, m1] = a.split("-").map(Number);
    const [y2, m2] = b.split("-").map(Number);
    return (y2 - y1) * 12 + (m2 - m1);
  };
  var sum = (arr, f = (x) => x) => arr.reduce((t, x) => t + f(x), 0);

  // js/defaults.js
  var ACCOUNT_TYPES = { cash: "Cash", bank: "Bank", ewallet: "E-Wallet", savings: "Savings", investment: "Investment", other: "Other" };
  var LIQUID = ["cash", "bank", "ewallet"];
  var SAVING_TYPES = ["savings", "investment"];
  var ASSET_TYPES = ["Deposito", "Investasi", "Kendaraan", "Properti", "Aset lain"];
  var DEBT_TYPES = ["Cicilan", "Pinjaman", "Utang kartu", "Utang pribadi", "Liabilitas lain"];
  var PRIORITIES = { high: "HIGH", medium: "MEDIUM", low: "LOW" };
  function defaultCategories() {
    const e = (name, subs) => ({ id: uid("cat"), name, kind: "expense", subs });
    const i = (name) => ({ id: uid("cat"), name, kind: "income", subs: [] });
    return [
      e("Kebutuhan", ["Makan", "Tempat tinggal", "Listrik", "Air", "Internet", "Pulsa", "Transportasi", "Laundry", "Kesehatan"]),
      e("Gaya Hidup", ["Nongkrong", "Kopi", "Hiburan", "Belanja online", "Hobi", "Liburan"]),
      e("Pengembangan Diri", ["Buku", "Kursus", "Sertifikasi", "Webinar", "Pendidikan", "AI Tools"]),
      e("Keluarga & Sosial", ["Orang tua", "Keluarga", "Donasi", "Hadiah"]),
      e("Keuangan", ["Investasi", "Dana darurat", "Tabungan", "Cicilan", "Pembayaran utang"]),
      ...["Gaji", "Freelance", "Bonus", "Kiriman", "Bisnis", "Investasi", "Lainnya"].map(i)
    ];
  }
  var MODES = {
    survive: { name: "SURVIVE", focus: ["Kebutuhan pokok", "Tempat tinggal", "Makanan", "Transportasi", "Kesehatan", "Tagihan wajib"], cats: ["Kebutuhan"] },
    stable: { name: "STABLE", focus: ["Kebutuhan pokok", "Dana darurat", "Tabungan", "Investasi", "Pengembangan diri"], cats: ["Kebutuhan", "Keuangan", "Pengembangan Diri"] },
    grow: { name: "GROW", focus: ["Investasi", "Pendidikan", "Skill", "Aset", "Financial goals"], cats: ["Keuangan", "Pengembangan Diri"] }
  };

  // js/calc.js
  var clamp = (v, a = 0, b = 100) => Math.max(a, Math.min(b, v));
  var catById = (S2, id) => S2.categories.find((c) => c.id === id);
  var accById = (S2, id) => S2.accounts.find((a) => a.id === id);
  var catName = (S2, id) => catById(S2, id)?.name || "Tanpa kategori";
  function balances(S2, upTo = null) {
    const b = {};
    S2.accounts.forEach((a) => b[a.id] = a.openingBalance || 0);
    for (const t of S2.transactions) {
      if (upTo && t.date > upTo) continue;
      if (t.type === "income") b[t.accountId] = (b[t.accountId] || 0) + t.amount;
      else if (t.type === "expense") b[t.accountId] = (b[t.accountId] || 0) - t.amount;
      else if (t.type === "transfer") {
        b[t.accountId] = (b[t.accountId] || 0) - t.amount;
        b[t.toAccountId] = (b[t.toAccountId] || 0) + t.amount;
      }
    }
    return b;
  }
  var totalBalance = (S2) => sum(Object.values(balances(S2)));
  var liquidBalance = (S2) => {
    const b = balances(S2);
    return sum(S2.accounts.filter((a) => LIQUID.includes(a.type)), (a) => b[a.id] || 0);
  };
  var liabilityPaid = (S2, l) => sum(S2.transactions.filter((t) => t.liabilityId === l.id), (t) => t.amount);
  var liabilityRemaining = (S2, l) => Math.max(0, (l.remaining || 0) - liabilityPaid(S2, l));
  var totalAssets = (S2) => totalBalance(S2) + sum(S2.assets, (a) => a.value || 0);
  var totalDebt = (S2) => sum(S2.liabilities.filter((l) => l.status !== "lunas"), (l) => liabilityRemaining(S2, l));
  var netWorth = (S2) => totalAssets(S2) - totalDebt(S2);
  function netWorthHistory(S2) {
    const first = S2.transactions.length ? S2.transactions.map((t) => t.date).sort()[0].slice(0, 7) : curMonth();
    const out = [];
    const extra = sum(S2.assets, (a) => a.value || 0) - totalDebt(S2);
    for (let mk = first; mk <= curMonth(); mk = addMonths(mk, 1)) {
      const end = mk === curMonth() ? today() : mk + "-" + String(daysInMonth(mk)).padStart(2, "0");
      out.push({ mk, value: sum(Object.values(balances(S2, end))) + extra });
    }
    return out;
  }
  function monthStats(S2, mk) {
    const txs = S2.transactions.filter((t) => monthKey(t.date) === mk);
    const income = sum(txs.filter((t) => t.type === "income"), (t) => t.amount);
    const expenseTx = txs.filter((t) => t.type === "expense");
    const expense = sum(expenseTx, (t) => t.amount);
    const byCat = {}, bySub = {};
    expenseTx.forEach((t) => {
      byCat[t.categoryId] = (byCat[t.categoryId] || 0) + t.amount;
      const k = t.categoryId + "|" + (t.sub || "");
      bySub[k] = (bySub[k] || 0) + t.amount;
    });
    const incByCat = {};
    txs.filter((t) => t.type === "income").forEach((t) => incByCat[t.categoryId] = (incByCat[t.categoryId] || 0) + t.amount);
    const savings = sum(txs.filter((t) => t.type === "transfer" && SAVING_TYPES.includes(accById(S2, t.toAccountId)?.type) && !SAVING_TYPES.includes(accById(S2, t.accountId)?.type)), (t) => t.amount);
    const debtPayment = sum(expenseTx.filter((t) => t.liabilityId), (t) => t.amount);
    const net = income - expense;
    return { mk, txs, income, expense, net, savings, debtPayment, byCat, bySub, incByCat, count: txs.length, savingRate: income > 0 ? net / income * 100 : null };
  }
  function budgetUsage(S2, mk) {
    const st = monthStats(S2, mk);
    return S2.budgets.map((b) => {
      const actual = b.sub ? st.bySub[b.categoryId + "|" + b.sub] || 0 : st.byCat[b.categoryId] || 0;
      const p = b.amount > 0 ? actual / b.amount * 100 : 0;
      return { ...b, actual, left: b.amount - actual, pct: p, state: p > 100 ? "over" : p >= 80 ? "warn" : "ok", label: b.sub || catName(S2, b.categoryId) };
    });
  }
  var goalCurrent = (S2, g) => (g.start || 0) + sum(S2.transactions.filter((t) => t.goalId === g.id), (t) => t.amount);
  var goalContribThisMonth = (S2, g) => sum(S2.transactions.filter((t) => t.goalId === g.id && monthKey(t.date) === curMonth()), (t) => t.amount);
  function goalPlan(S2, g) {
    const current2 = goalCurrent(S2, g), remaining = Math.max(0, g.target - current2);
    const progress = g.target > 0 ? clamp(current2 / g.target * 100, 0, 100) : 0;
    const r = { current: current2, remaining, progress, status: "none", required: 0, forecastMonths: null, forecastLabel: null };
    if (remaining === 0) {
      r.status = "done";
      return r;
    }
    if (g.monthly > 0) {
      r.forecastMonths = Math.ceil(remaining / g.monthly);
      r.forecastLabel = monthLabel(addMonths(curMonth(), r.forecastMonths));
    }
    if (g.deadline) {
      if (g.deadline < today()) {
        r.status = "overdue";
        return r;
      }
      const m = Math.max(1, monthsBetween(curMonth(), g.deadline.slice(0, 7)));
      r.required = Math.ceil(remaining / m);
      r.status = (g.monthly || 0) >= r.required ? "track" : "short";
    }
    return r;
  }
  function emergency(S2) {
    const g = S2.goals.find((x) => x.isEmergency);
    const mandatory = S2.profile?.mandatoryExpense || 0, months = S2.profile?.efMonths || 0;
    const current2 = g ? goalCurrent(S2, g) : 0;
    const target = mandatory * months;
    return { goal: g, mandatory, months, target, current: current2, coverage: mandatory > 0 ? current2 / mandatory : 0, progress: target > 0 ? clamp(current2 / target * 100) : 0 };
  }
  function safeToSpend(S2) {
    const t = today(), mk = curMonth(), day = Number(t.slice(8)), left = daysInMonth(mk) - day + 1;
    const liquid = liquidBalance(S2);
    const bills = sum(S2.recurring.filter((r) => r.active && r.type === "expense" && r.lastRun < mk && clampDay(mk, r.day) >= day), (r) => r.amount) + sum(S2.liabilities.filter((l) => l.status !== "lunas" && l.installment > 0 && l.dueDay >= day && !S2.transactions.some((x) => x.liabilityId === l.id && monthKey(x.date) === mk)), (l) => l.installment);
    const available = liquid - bills;
    const goalNeed = sum(S2.goals.filter((g) => g.monthly > 0 && goalPlan(S2, g).status !== "done"), (g) => Math.max(0, g.monthly - goalContribThisMonth(S2, g)));
    const after = available - goalNeed;
    return { liquid, bills, available, daysLeft: left, perDay: Math.max(0, Math.floor(available / left)), goalNeed, after, perDayAfter: Math.max(0, Math.floor(after / left)) };
  }
  function healthScore(S2) {
    const st = monthStats(S2, curMonth()), ef = emergency(S2), bu = budgetUsage(S2, curMonth());
    const incomeBase = st.income || S2.profile?.monthlyIncome || 0;
    const comps = [];
    const add = (key, label, weight, score, note) => comps.push({ key, label, weight, score: score == null ? null : Math.round(clamp(score)), note });
    add("sr", "Saving rate", 25, st.savingRate == null ? null : st.savingRate / 20 * 100, st.savingRate == null ? "Belum ada pemasukan bulan ini." : `Saving rate ${st.savingRate.toFixed(0)}% (acuan penuh: 20%).`);
    add("ef", "Dana darurat", 20, ef.mandatory > 0 && ef.months > 0 ? ef.coverage / ef.months * 100 : null, ef.mandatory > 0 ? `Cakupan ${ef.coverage.toFixed(1).replace(".", ",")} dari ${ef.months} bulan target.` : "Isi pengeluaran wajib & target bulan.");
    const inst = sum(S2.liabilities.filter((l) => l.status !== "lunas"), (l) => l.installment || 0);
    add("debt", "Rasio utang", 15, incomeBase > 0 ? inst === 0 ? 100 : (0.4 - inst / incomeBase) / 0.3 * 100 : null, inst === 0 ? "Tidak ada cicilan aktif." : `Cicilan ${(incomeBase ? inst / incomeBase * 100 : 0).toFixed(0)}% dari pemasukan.`);
    add("budget", "Kepatuhan budget", 15, bu.length ? bu.filter((b) => b.pct <= 100).length / bu.length * 100 : null, bu.length ? `${bu.filter((b) => b.pct <= 100).length} dari ${bu.length} budget masih dalam batas.` : "Belum ada budget.");
    add("cash", "Cash flow", 10, st.income + st.expense === 0 ? null : st.net >= 0 ? 100 : st.income > 0 ? 100 + st.net / st.income * 200 : 0, st.income + st.expense === 0 ? "Belum ada transaksi bulan ini." : st.net >= 0 ? "Cash flow bulan ini positif." : "Pengeluaran melebihi pemasukan bulan ini.");
    const gs = S2.goals.filter((g) => !g.isEmergency);
    add("goal", "Progres target", 15, gs.length ? sum(gs, (g) => goalPlan(S2, g).progress) / gs.length : null, gs.length ? "Rata-rata progres seluruh target." : "Belum ada target.");
    const used = comps.filter((c) => c.score != null), w = sum(used, (c) => c.weight);
    const total = w ? Math.round(sum(used, (c) => c.score * c.weight) / w) : null;
    return { total, comps, status: total == null ? "\u2014" : total >= 75 ? "Sehat" : total >= 50 ? "Cukup stabil" : "Perlu perhatian" };
  }
  function insights(S2) {
    const out = [], mk = curMonth(), prev = addMonths(mk, -1);
    if (S2.transactions.length < 5) return out;
    const st = monthStats(S2, mk), pv = monthStats(S2, prev), fmt = (n) => "Rp " + String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    const p0 = (v) => v.toFixed(0) + "%";
    if (st.expense > 0) {
      const top = Object.entries(st.byCat).sort((a, b) => b[1] - a[1]).slice(0, 2);
      top.forEach(([id, v]) => out.push({ tone: "info", text: `${catName(S2, id)} menggunakan ${p0(v / st.expense * 100)} dari total pengeluaran bulan ini.` }));
    }
    Object.entries(st.byCat).forEach(([id, v]) => {
      const was = pv.byCat[id] || 0;
      if (was >= 5e4 && v > was * 1.1) out.push({ tone: "warn", text: `Pengeluaran ${catName(S2, id)} bulan ini ${p0((v / was - 1) * 100)} lebih tinggi dibanding total bulan lalu.` });
    });
    const past = [addMonths(mk, -1), addMonths(mk, -2), addMonths(mk, -3)].map((m) => monthStats(S2, m)).filter((m) => m.count > 0);
    if (past.length >= 2) Object.entries(st.byCat).forEach(([id, v]) => {
      const avg = sum(past, (m) => m.byCat[id] || 0) / past.length;
      if (avg > 0 && v > avg * 1.5 && v - avg > 5e4) out.push({ tone: "warn", text: `Pengeluaran ${catName(S2, id)} meningkat dibanding rata-rata Anda (${fmt(avg)}/bulan).` });
    });
    if (st.savingRate != null) out.push({ tone: st.savingRate >= 20 ? "good" : "info", text: `Saving rate bulan ini ${p0(st.savingRate)}.` });
    budgetUsage(S2, mk).forEach((b) => {
      if (b.state === "over") out.push({ tone: "bad", text: `Budget ${b.label} terlampaui ${fmt(-b.left)}.` });
      else if (b.state === "warn") out.push({ tone: "warn", text: `Budget ${b.label} sudah terpakai ${p0(b.pct)}.` });
    });
    S2.goals.filter((g) => g.monthly > 0).sort((a, b) => "hml".indexOf(a.priority[0]) - "hml".indexOf(b.priority[0])).slice(0, 1).forEach((g) => {
      const p = goalPlan(S2, g);
      if (p.forecastMonths) out.push({ tone: "info", text: `Dengan kontribusi ${fmt(g.monthly)}/bulan, target ${g.name} diperkirakan tercapai dalam ${p.forecastMonths} bulan.` });
    });
    return out;
  }
  function cashflowBuckets(S2, range, from, to) {
    const labels = [], inc = [], exp = [], keys = [];
    const add = (label, pred) => {
      const tx2 = S2.transactions.filter(pred);
      labels.push(label);
      inc.push(sum(tx2.filter((t) => t.type === "income"), (t) => t.amount));
      exp.push(sum(tx2.filter((t) => t.type === "expense"), (t) => t.amount));
    };
    const dayRange = (a, b) => {
      const days = [];
      for (let d = parseYmd(a); ymd(d) <= b; d.setDate(d.getDate() + 1)) days.push(ymd(d));
      return days;
    };
    if (range === "week") {
      const e = parseYmd(today());
      const s = new Date(e);
      s.setDate(s.getDate() - 6);
      dayRange(ymd(s), today()).forEach((d) => add(d.slice(8), (t) => t.date === d));
    } else if (range === "month") {
      const mk = curMonth(), n = daysInMonth(mk);
      [[1, 7], [8, 14], [15, 21], [22, 28], [29, n]].filter(([a]) => a <= n).forEach(([a, b]) => add(`${a}\u2013${b}`, (t) => monthKey(t.date) === mk && +t.date.slice(8) >= a && +t.date.slice(8) <= b));
    } else if (range === "year") {
      const y = today().slice(0, 4);
      MON3.forEach((m, i) => add(m, (t) => t.date.startsWith(y + "-" + String(i + 1).padStart(2, "0"))));
    } else if (from && to && from <= to) {
      const days = dayRange(from, to);
      if (days.length <= 31) days.forEach((d) => add(d.slice(8), (t) => t.date === d));
      else for (let mk = from.slice(0, 7); mk <= to.slice(0, 7); mk = addMonths(mk, 1)) add(MON3[+mk.slice(5) - 1], (t) => monthKey(t.date) === mk && t.date >= from && t.date <= to);
    }
    return { labels, inc, exp, totalIncome: sum(inc), totalExpense: sum(exp) };
  }
  function buildSnapshots(S2) {
    const hist = netWorthHistory(S2);
    return hist.map((h) => {
      const m = monthStats(S2, h.mk);
      return { id: h.mk, mk: h.mk, income: m.income, expense: m.expense, savings: m.savings, debtPayment: m.debtPayment, netWorth: h.value, updatedAt: now() };
    });
  }
  function dueRecurring(S2, todayStr = today()) {
    const newTx = [], updated = [], mkNow = todayStr.slice(0, 7), dayNow = +todayStr.slice(8);
    for (const r of S2.recurring) {
      if (!r.active) continue;
      let last = r.lastRun || addMonths(mkNow, -1), changed = false;
      if (monthsBetween(last, mkNow) > 12) last = addMonths(mkNow, -12);
      for (let mk = addMonths(last, 1); mk <= mkNow; mk = addMonths(mk, 1)) {
        const d = clampDay(mk, r.day);
        if (mk === mkNow && d > dayNow) break;
        newTx.push({ id: uid("tx"), type: r.type, date: `${mk}-${String(d).padStart(2, "0")}`, accountId: r.accountId, categoryId: r.categoryId, sub: r.sub || "", amount: r.amount, note: r.name + " (berulang)", recurringId: r.id, createdAt: now(), updatedAt: now() });
        last = mk;
        changed = true;
      }
      if (changed) updated.push({ ...r, lastRun: last });
    }
    return { newTx, updated };
  }
  function reminders(S2, horizon = 7) {
    const t = today(), out = [], mk = curMonth();
    const dueIn = (day) => {
      let d = `${mk}-${String(clampDay(mk, day)).padStart(2, "0")}`;
      if (d < t) {
        const n = addMonths(mk, 1);
        d = `${n}-${String(clampDay(n, day)).padStart(2, "0")}`;
      }
      return d;
    };
    S2.liabilities.filter((l) => l.status !== "lunas" && l.dueDay).forEach((l) => {
      const d = dueIn(l.dueDay), n = Math.round((parseYmd(d) - parseYmd(t)) / 864e5);
      if (n <= horizon) out.push({ days: n, text: `Utang ${l.name} jatuh tempo ${n === 0 ? "hari ini" : n + " hari lagi"} (${dateShort(d)}).` });
    });
    S2.recurring.filter((r) => r.active).forEach((r) => {
      const d = dueIn(r.day), n = Math.round((parseYmd(d) - parseYmd(t)) / 864e5);
      if (n <= horizon && r.lastRun < d.slice(0, 7)) out.push({ days: n, text: `${r.name} (berulang) dijadwalkan ${n === 0 ? "hari ini" : n + " hari lagi"}.` });
    });
    S2.goals.forEach((g) => {
      const p = goalPlan(S2, g);
      if (p.status === "short") out.push({ days: 99, text: `Target ${g.name} membutuhkan Rp ${String(p.required).replace(/\B(?=(\d{3})+(?!\d))/g, ".")}/bulan.` });
    });
    return out.sort((a, b) => a.days - b.days);
  }
  var modeInfo = (key) => MODES[key] || MODES.stable;

  // js/store.js
  var S = { profile: null, settings: null, accounts: [], transactions: [], categories: [], budgets: [], goals: [], assets: [], liabilities: [], recurring: [], scenarios: [], snapshots: [] };
  var LISTS = ["accounts", "transactions", "categories", "budgets", "goals", "assets", "liabilities", "recurring", "scenarios", "snapshots"];
  var defaultSettings = () => ({ id: "main", theme: "system", hide: false, pinHash: null, mode: "stable", lastBackup: null, lastChange: null, lastAccountId: null, notify: false, demo: false });
  var listener = () => {
  };
  var onChange = (fn) => listener = fn;
  async function init() {
    await openDB();
    const all = await loadAll();
    LISTS.forEach((k) => S[k] = all[k]);
    S.profile = all.profile[0] || null;
    S.settings = all.settings[0] || defaultSettings();
    if (!S.categories.length) {
      S.categories = defaultCategories();
      await putMany("categories", S.categories);
    }
    if (!all.settings.length) await put("settings", S.settings);
    if (navigator.storage?.persist) navigator.storage.persist().catch(() => {
    });
    await runRecurring();
  }
  var touch = async () => {
    S.settings.lastChange = now();
    await put("settings", S.settings);
  };
  async function refreshSnapshots() {
    S.snapshots = buildSnapshots(S);
    await clear("snapshots");
    await putMany("snapshots", S.snapshots);
  }
  async function save(list, obj) {
    if (!obj.id) obj.id = uid(list.slice(0, 3));
    await put(list, obj);
    const i = S[list].findIndex((x) => x.id === obj.id);
    if (i >= 0) S[list][i] = obj;
    else S[list].push(obj);
    await touch();
    if (list === "transactions") await refreshSnapshots();
    listener();
    return obj;
  }
  async function remove(list, id) {
    await del(list, id);
    S[list] = S[list].filter((x) => x.id !== id);
    await touch();
    if (list === "transactions") await refreshSnapshots();
    listener();
  }
  async function saveProfile(p) {
    S.profile = { ...S.profile || {}, ...p, id: "me" };
    await put("profile", S.profile);
    await touch();
    listener();
  }
  async function saveSettings(patch) {
    Object.assign(S.settings, patch);
    await put("settings", S.settings);
    listener();
  }
  async function saveTx(d, editId = null) {
    const amount = Math.round(d.amount);
    if (!(amount > 0)) return { error: "Nominal harus lebih besar dari Rp0." };
    if (!validDate(d.date)) return { error: "Tanggal tidak valid." };
    if (!d.accountId || !accById(S, d.accountId)) return { error: "Pilih akun terlebih dahulu." };
    if (d.type !== "transfer" && !d.categoryId) return { error: "Pilih kategori terlebih dahulu." };
    if (d.type === "transfer") {
      if (!d.toAccountId) return { error: "Pilih akun tujuan." };
      if (d.toAccountId === d.accountId) return { error: "Akun sumber dan tujuan harus berbeda." };
    }
    if (d.type !== "income") {
      const others = { ...S, transactions: S.transactions.filter((t2) => t2.id !== editId) };
      if ((balances(others)[d.accountId] || 0) < amount) return { error: "Saldo akun tidak mencukupi." };
    }
    const old = editId ? S.transactions.find((t2) => t2.id === editId) : null;
    const t = {
      ...old || {},
      id: editId || uid("tx"),
      type: d.type,
      date: d.date,
      accountId: d.accountId,
      toAccountId: d.type === "transfer" ? d.toAccountId : null,
      categoryId: d.type === "transfer" ? null : d.categoryId,
      sub: d.type === "transfer" ? "" : d.sub || "",
      amount,
      note: (d.note || "").trim(),
      goalId: d.goalId || null,
      liabilityId: d.liabilityId || null,
      createdAt: old?.createdAt || now(),
      updatedAt: now()
    };
    await save("transactions", t);
    await saveSettings({ lastAccountId: t.accountId });
    return { ok: true, tx: t };
  }
  async function deleteAccount(id) {
    const n = S.transactions.filter((t) => t.accountId === id || t.toAccountId === id).length;
    if (n) return { error: `Rekening masih dipakai ${n} transaksi. Hapus atau pindahkan transaksinya dulu.` };
    await remove("accounts", id);
    return { ok: true };
  }
  async function deleteCategory(id) {
    const n = S.transactions.filter((t) => t.categoryId === id).length;
    if (n) return { error: `Kategori masih dipakai ${n} transaksi.` };
    for (const b of S.budgets.filter((b2) => b2.categoryId === id)) await remove("budgets", b.id);
    await remove("categories", id);
    return { ok: true };
  }
  async function payDebt(l, { amount, accountId, date }) {
    if (amount > liabilityRemaining(S, l)) return { error: "Pembayaran melebihi sisa utang." };
    let cat = S.categories.find((c) => c.name === "Keuangan" && c.kind === "expense") || S.categories.find((c) => c.kind === "expense");
    const r = await saveTx({ type: "expense", date, accountId, categoryId: cat?.id, sub: "Pembayaran utang", amount, note: "Bayar " + l.name, liabilityId: l.id });
    if (r.ok && liabilityRemaining(S, l) === 0) await save("liabilities", { ...l, status: "lunas" });
    return r;
  }
  async function contributeGoal(g, { amount, accountId, toAccountId, date }) {
    return saveTx({ type: "transfer", date, accountId, toAccountId, amount, note: "Setor ke " + g.name, goalId: g.id });
  }
  async function runRecurring() {
    const { newTx, updated } = dueRecurring(S);
    if (!newTx.length) return 0;
    for (const t of newTx) {
      await put("transactions", t);
      S.transactions.push(t);
    }
    for (const r of updated) {
      await put("recurring", r);
      S.recurring = S.recurring.map((x) => x.id === r.id ? r : x);
    }
    await touch();
    await refreshSnapshots();
    listener();
    return newTx.length;
  }
  async function completeOnboarding(o) {
    await saveProfile({ name: o.name, currency: "IDR", monthlyIncome: o.income, mandatoryExpense: o.mandatory, efMonths: o.efMonths, onboarded: true });
    const acc = { id: uid("acc"), name: o.accName || "Rekening Utama", type: o.accType || "bank", openingBalance: o.balance || 0, note: "", createdAt: now() };
    await save("accounts", acc);
    await save("goals", { id: uid("goal"), name: "Dana Darurat", target: o.mandatory * o.efMonths, start: 0, deadline: "", priority: "high", monthly: 0, isEmergency: true, createdAt: now() });
  }
  async function syncEmergencyTarget() {
    const g = S.goals.find((x) => x.isEmergency);
    if (g) await save("goals", { ...g, target: (S.profile.mandatoryExpense || 0) * (S.profile.efMonths || 0) });
  }
  function exportJSON() {
    const data = { app: "ChemFinance", version: 1, exportedAt: now(), profile: S.profile ? [S.profile] : [], settings: [{ ...S.settings, pinHash: S.settings.pinHash }] };
    LISTS.forEach((k) => data[k] = S[k]);
    return JSON.stringify(data, null, 1);
  }
  function exportCSV() {
    const q = (v) => '"' + String(v ?? "").replace(/"/g, '""') + '"';
    const catName2 = (id) => S.categories.find((c) => c.id === id)?.name || "";
    const accName2 = (id) => accById(S, id)?.name || "";
    const rows = [["Tanggal", "Tipe", "Akun", "Akun Tujuan", "Kategori", "Subkategori", "Nominal", "Catatan"].map(q).join(",")];
    [...S.transactions].sort((a, b) => a.date.localeCompare(b.date)).forEach((t) => rows.push([t.date, t.type, accName2(t.accountId), accName2(t.toAccountId), catName2(t.categoryId), t.sub, t.amount, t.note].map(q).join(",")));
    return "\uFEFF" + rows.join("\r\n");
  }
  async function markBackup() {
    await saveSettings({ lastBackup: now() });
  }
  function validateBackup(d) {
    if (!d || d.app !== "ChemFinance") return "Berkas bukan backup ChemFinance.";
    for (const k of ["accounts", "transactions", "categories"]) if (!Array.isArray(d[k])) return `Backup rusak: bagian "${k}" tidak ditemukan.`;
    for (const t of d.transactions) if (!t.id || !validDate(t.date) || !(t.amount > 0)) return "Backup rusak: ada transaksi yang tidak valid.";
    return null;
  }
  async function importBackup(d) {
    const err = validateBackup(d);
    if (err) return { error: err };
    const payload = {};
    LISTS.forEach((k) => payload[k] = d[k] || []);
    payload.profile = d.profile || [];
    payload.settings = d.settings?.length ? d.settings : [defaultSettings()];
    await replaceAll(payload);
    LISTS.forEach((k) => S[k] = payload[k]);
    S.profile = payload.profile[0] || null;
    S.settings = payload.settings[0];
    await refreshSnapshots();
    listener();
    return { ok: true };
  }
  async function resetAll({ keepProfile = false } = {}) {
    const prof = S.profile, set = S.settings;
    await replaceAll({});
    LISTS.forEach((k) => S[k] = []);
    S.categories = defaultCategories();
    await putMany("categories", S.categories);
    S.settings = { ...defaultSettings(), ...keepProfile ? { theme: set.theme, pinHash: set.pinHash } : {} };
    S.profile = keepProfile ? prof : null;
    await put("settings", S.settings);
    if (S.profile) await put("profile", S.profile);
    listener();
  }
  async function hashPin(pin) {
    const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode("chemfinance:" + pin));
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, "0")).join("");
  }

  // js/ui.js
  var $ = (s, r = document) => r.querySelector(s);
  var $$ = (s, r = document) => [...r.querySelectorAll(s)];
  var money = (n) => S.settings?.hide ? "Rp \u2022\u2022\u2022\u2022\u2022\u2022" : rp(n);
  var short = (n) => {
    const a = Math.abs(n);
    const s = a >= 1e9 ? (a / 1e9).toFixed(1).replace(".", ",") + " M" : a >= 1e6 ? (a / 1e6).toFixed(1).replace(".", ",").replace(",0", "") + " jt" : a >= 1e3 ? Math.round(a / 1e3) + " rb" : String(a);
    return (n < 0 ? "\u2212" : "") + s;
  };
  function toast(msg, ms = 2600) {
    const t = $("#toast");
    t.textContent = msg;
    t.classList.add("show");
    clearTimeout(toast.t);
    toast.t = setTimeout(() => t.classList.remove("show"), ms);
  }
  var sheetEl;
  function openSheet(title, html, mount) {
    closeSheet();
    sheetEl = document.createElement("div");
    sheetEl.className = "backdrop";
    sheetEl.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-label="${esc(title)}"><div class="sheet-h"><h2>${esc(title)}</h2><button class="icon-btn" data-close aria-label="Tutup">\u2715</button></div><div class="sheet-b">${html}</div></div>`;
    sheetEl.addEventListener("click", (e) => {
      if (e.target === sheetEl || e.target.closest("[data-close]")) closeSheet();
    });
    document.body.appendChild(sheetEl);
    document.body.classList.add("noscroll");
    mount?.(sheetEl.querySelector(".sheet-b"));
    return sheetEl.querySelector(".sheet-b");
  }
  function closeSheet() {
    sheetEl?.remove();
    sheetEl = null;
    document.body.classList.remove("noscroll");
  }
  function confirmBox({ title = "Konfirmasi", message, okText = "Ya", danger = false }) {
    return new Promise((resolve) => {
      const d = document.createElement("div");
      d.className = "backdrop center";
      d.innerHTML = `<div class="dialog" role="alertdialog" aria-modal="true"><h2>${esc(title)}</h2><p>${esc(message)}</p><div class="btn-row"><button class="btn ghost" data-v="0">Batal</button><button class="btn ${danger ? "danger" : "primary"}" data-v="1">${esc(okText)}</button></div></div>`;
      d.addEventListener("click", (e) => {
        const b = e.target.closest("[data-v]");
        if (b || e.target === d) {
          d.remove();
          resolve(b?.dataset.v === "1");
        }
      });
      document.body.appendChild(d);
    });
  }
  function fieldHtml(f) {
    const id = "f_" + f.id, v = f.value ?? "";
    let c;
    if (f.type === "select") c = `<select id="${id}">${f.options.map(([val, lab]) => `<option value="${esc(val)}" ${String(val) === String(v) ? "selected" : ""}>${esc(lab)}</option>`).join("")}</select>`;
    else if (f.type === "textarea") c = `<textarea id="${id}" rows="2" placeholder="${esc(f.placeholder || "")}">${esc(v)}</textarea>`;
    else if (f.type === "money") c = `<input id="${id}" data-money inputmode="numeric" autocomplete="off" placeholder="0" value="${v ? dots(v) : ""}">`;
    else if (f.type === "number") c = `<input id="${id}" type="number" inputmode="decimal" min="${f.min ?? ""}" max="${f.max ?? ""}" step="${f.step ?? "any"}" value="${esc(v)}" placeholder="${esc(f.placeholder || "")}">`;
    else if (f.type === "date") c = `<input id="${id}" type="date" value="${esc(v)}">`;
    else c = `<input id="${id}" type="${f.type === "password" ? "password" : "text"}" ${f.type === "password" ? 'inputmode="numeric" autocomplete="off"' : ""} maxlength="${f.max || 80}" value="${esc(v)}" placeholder="${esc(f.placeholder || "")}">`;
    return `<div class="field"><label for="${id}">${esc(f.label)}</label>${c}${f.hint ? `<div class="hint">${esc(f.hint)}</div>` : ""}</div>`;
  }
  function readFields(root, fields) {
    const out = {};
    fields.forEach((f) => {
      const el = root.querySelector("#f_" + f.id);
      if (!el) return;
      out[f.id] = f.type === "money" ? parseAmount(el.value) : f.type === "number" ? el.value === "" ? null : Number(el.value) : el.value.trim();
    });
    return out;
  }
  function formSheet({ title, fields, submitText = "Simpan", onSubmit, onDelete, deleteText = "Hapus", intro = "" }) {
    const html = `${intro ? `<p class="muted small">${esc(intro)}</p>` : ""}<div class="form-error" role="alert" id="ferr"></div>${fields.map(fieldHtml).join("")}<div class="btn-row"><button class="btn primary" id="fsave">${esc(submitText)}</button>${onDelete ? `<button class="btn danger-o" id="fdel">${esc(deleteText)}</button>` : ""}</div>`;
    openSheet(title, html, (root) => {
      const err = (m) => {
        $("#ferr", root).textContent = m || "";
        if (m) $("#ferr", root).scrollIntoView({ block: "nearest" });
      };
      $("#fsave", root).onclick = async () => {
        const m = await onSubmit(readFields(root, fields));
        if (m) err(m);
        else closeSheet();
      };
      if (onDelete) $("#fdel", root).onclick = async () => {
        const m = await onDelete();
        if (m) err(m);
        else closeSheet();
      };
      root.querySelector("input,select,textarea")?.focus({ preventScroll: true });
    });
  }
  function bindMoneyInputs() {
    document.addEventListener("input", (e) => {
      const el = e.target;
      if (el.matches?.("[data-money]")) {
        const n = parseAmount(el.value);
        el.value = n ? dots(n) : "";
      }
    });
  }
  var bar = (p, state = "ok", label = "") => `<div class="bar" role="progressbar" aria-valuenow="${Math.round(Math.min(p, 100))}" aria-valuemin="0" aria-valuemax="100" aria-label="${esc(label)}"><div class="bar-fill ${state}" style="width:${Math.min(Math.max(p, 0), 100)}%"></div></div>`;
  var empty = (title, text, btn = "") => `<div class="empty"><strong>${esc(title)}</strong><p>${esc(text)}</p>${btn}</div>`;
  var badge = (text, tone = "neutral") => `<span class="pill ${tone}">${esc(text)}</span>`;
  function groupedBars(labels, inc, exp) {
    const W = 340, H = 150, top = 14, bot = 22, n = labels.length, max = Math.max(...inc, ...exp, 1), gw = W / n, bw = Math.min(14, gw * 0.36), ch = H - top - bot;
    const y = (v) => top + ch - v / max * ch;
    let g = `<line x1="0" x2="${W}" y1="${top + ch}" y2="${top + ch}" class="ax-line"/>`;
    labels.forEach((l, i) => {
      const cx = gw * i + gw / 2;
      g += `<rect x="${cx - bw - 1}" y="${y(inc[i])}" width="${bw}" height="${top + ch - y(inc[i])}" class="b-inc"/><rect x="${cx + 1}" y="${y(exp[i])}" width="${bw}" height="${top + ch - y(exp[i])}" class="b-exp"/>`;
      if (n <= 12 || i % Math.ceil(n / 12) === 0) g += `<text x="${cx}" y="${H - 6}" text-anchor="middle" class="ax">${esc(l)}</text>`;
    });
    return `<svg viewBox="0 0 ${W} ${H}" class="chart" role="img" aria-label="Grafik pemasukan dan pengeluaran"><text x="0" y="9" class="ax">${S.settings?.hide ? "" : short(max)}</text>${g}</svg><div class="legend"><span><i class="dot inc"></i>Pemasukan</span><span><i class="dot exp"></i>Pengeluaran</span></div>`;
  }
  function lineChart(labels, vals) {
    const W = 340, H = 130, p = 10, n = vals.length, min = Math.min(...vals, 0), max = Math.max(...vals, 1), span = max - min || 1;
    const pt = (v, i) => [p + (n === 1 ? (W - 2 * p) / 2 : i / (n - 1) * (W - 2 * p)), H - 24 - (v - min) / span * (H - 44)];
    const pts = vals.map(pt);
    return `<svg viewBox="0 0 ${W} ${H}" class="chart" role="img" aria-label="Grafik net worth"><polyline points="${pts.map((q) => q.join(",")).join(" ")}" class="line"/>${pts.map((q) => `<circle cx="${q[0]}" cy="${q[1]}" r="3" class="pt"/>`).join("")}${labels.map((l, i) => n <= 8 || i % Math.ceil(n / 8) === 0 ? `<text x="${pts[i][0]}" y="${H - 6}" text-anchor="middle" class="ax">${esc(l)}</text>` : "").join("")}</svg>`;
  }

  // js/views-main.js
  var catLabel = (t) => t.type === "transfer" ? "Transfer" : catName(S, t.categoryId) + (t.sub ? " \u203A " + t.sub : "");
  var accName = (id) => accById(S, id)?.name || "\u2014";
  var stateLabel = { ok: "Dalam batas", warn: "Hampir habis", over: "Melebihi budget" };
  function txRow(t) {
    const kind = t.type, sign = kind === "income" ? "+ " : kind === "expense" ? "\u2212 " : "";
    const sub = kind === "transfer" ? `${esc(accName(t.accountId))} \u2192 ${esc(accName(t.toAccountId))}` : esc(accName(t.accountId));
    const amt = S.settings.hide ? "Rp \u2022\u2022\u2022\u2022\u2022\u2022" : sign + "Rp " + dots(t.amount);
    return `<button class="row" data-act="editTx" data-id="${t.id}"><div class="row-main"><div class="row-t">${esc(catLabel(t))}</div><div class="row-s">${t.note ? esc(t.note) + " \xB7 " : ""}${sub}</div></div><div class="row-amt ${kind === "income" ? "pos" : kind === "expense" ? "neg" : ""}">${amt}</div></button>`;
  }
  var dayGroup = (list) => {
    const by = {};
    list.forEach((t) => (by[t.date] ||= []).push(t));
    return Object.keys(by).sort().reverse().map((d) => `<div class="day-h">${dateShort(d)} \xB7 ${dayName(d)}</div><div class="list">${by[d].map(txRow).join("")}</div>`).join("");
  };
  function home() {
    const mk = curMonth(), st = monthStats(S, mk), nw = netWorth(S), ef = emergency(S), bu = budgetUsage(S, mk), hs = healthScore(S), sp = safeToSpend(S), ins = insights(S), rem = reminders(S);
    const recent = [...S.transactions].sort((a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt)).slice(0, 5);
    const goals = S.goals.filter((g) => !g.isEmergency && goalPlan(S, g).status !== "done").slice(0, 2);
    const noData = !S.transactions.length;
    const h = `
  ${rem.length ? `<div class="card note"><div class="card-h"><h3>Pengingat</h3></div>${rem.slice(0, 3).map((r) => `<p class="small">${esc(r.text)}</p>`).join("")}</div>` : ""}
  <section class="card hero"><div class="lbl">Net worth</div><div class="big">${money(nw)}</div>
    <div class="hero-sub"><span>Aset ${money(totalAssets(S))}</span><span>Utang ${money(totalDebt(S))}</span></div></section>
  <div class="grid2">
    <div class="card stat"><div class="lbl">Total saldo</div><div class="val">${money(totalBalance(S))}</div></div>
    <div class="card stat"><div class="lbl">Saving rate</div><div class="val">${st.savingRate == null ? "\u2014" : pct(st.savingRate)}</div></div>
    <div class="card stat"><div class="lbl">Pendapatan \xB7 ${monthLabel(mk).split(" ")[0]}</div><div class="val pos">${money(st.income)}</div></div>
    <div class="card stat"><div class="lbl">Pengeluaran</div><div class="val neg">${money(st.expense)}</div></div>
  </div>
  <div class="card"><div class="card-h"><h3>Cash flow bulan ini</h3><span class="val ${st.net >= 0 ? "pos" : "neg"}">${money(st.net)}</span></div>
    ${st.count ? groupedBars(...(({ labels, inc, exp }) => [labels, inc, exp])(cashflowBuckets(S, "month"))) : '<p class="muted small">Belum ada transaksi bulan ini.</p>'}</div>
  <div class="card"><div class="card-h"><h3>Safe-to-spend</h3></div>
    <div class="grid2 tight"><div><div class="lbl">Per hari</div><div class="val">${money(sp.perDay)}</div></div><div><div class="lbl">Sisa ${sp.daysLeft} hari</div><div class="val">${money(sp.available)}</div></div></div>
    ${sp.goalNeed > 0 ? `<p class="small muted">Setelah target tabungan bulan ini (${money(sp.goalNeed)}): ${money(Math.max(0, sp.after))} \xB7 ${money(sp.perDayAfter)}/hari.</p>` : ""}
    <p class="hint">Dihitung dari saldo Cash/Bank/E-Wallet dikurangi tagihan yang belum jatuh tempo.</p></div>
  ${S.budgets.length ? `<div class="card"><div class="card-h"><h3>Budget</h3><button class="link" data-nav="budget">Lihat semua</button></div>${bu.sort((a, b) => b.pct - a.pct).slice(0, 3).map(budgetItem).join("")}</div>` : ""}
  <div class="card"><div class="card-h"><h3>Target</h3><button class="link" data-nav="goals">Lihat semua</button></div>
    ${ef.target > 0 ? `<div class="item"><div class="item-h"><span>Dana Darurat</span><span>${ef.coverage.toFixed(1).replace(".", ",")} / ${ef.months} bulan</span></div>${bar(ef.progress, "ok", "Dana darurat")}<div class="small muted">${money(ef.current)} dari ${money(ef.target)}</div></div>` : ""}
    ${goals.map((g) => goalItem(g, false)).join("") || (ef.target > 0 ? "" : '<p class="muted small">Belum ada target.</p>')}</div>
  <div class="card"><div class="card-h"><h3>ChemFinance Health Score</h3><button class="link" data-act="healthInfo">Detail</button></div>
    <div class="score"><span class="score-n">${hs.total ?? "\u2014"}</span><span class="muted">/ 100</span>${badge(hs.status, hs.total >= 75 ? "good" : hs.total >= 50 ? "warn" : "bad")}</div></div>
  ${ins.length ? `<div class="card"><div class="card-h"><h3>Insight</h3></div>${ins.slice(0, 4).map((i) => `<p class="insight ${i.tone}">${esc(i.text)}</p>`).join("")}</div>` : noData ? "" : '<div class="card"><p class="muted small">Insight akan muncul setelah data transaksi cukup.</p></div>'}
  <div class="card"><div class="card-h"><h3>Transaksi terbaru</h3><button class="link" data-nav="tx">Semua</button></div>
    ${recent.length ? `<div class="list flush">${recent.map(txRow).join("")}</div>` : empty("Belum ada transaksi.", "Mulai dengan mencatat pemasukan atau pengeluaran pertama Anda.", '<button class="btn primary" data-act="addTx">Catat transaksi</button>')}</div>
  ${noData && !S.settings.demo ? '<p class="center small muted">Ingin melihat contoh? <button class="link" data-act="loadDemo">Load Demo Data</button></p>' : ""}`;
    return { title: "Home", html: h };
  }
  function budgetItem(b) {
    return `<button class="item btn-reset" data-act="editBudget" data-id="${b.id}"><div class="item-h"><span>${esc(b.label)}</span><span>${pct(b.pct, 0)}</span></div>${bar(b.pct, b.state, b.label)}
  <div class="small ${b.state === "over" ? "neg" : "muted"}">${money(b.actual)} / ${money(b.amount)} \xB7 ${b.state === "over" ? "Melebihi " + money(-b.left) : "Sisa " + money(b.left)} \xB7 ${stateLabel[b.state]}</div></button>`;
  }
  function goalItem(g, full = true) {
    const p = goalPlan(S, g);
    const msg = p.status === "done" ? "Target tercapai." : p.status === "overdue" ? "Deadline terlewat." : p.status === "short" ? `Target membutuhkan ${money(p.required)}/bulan.` : p.status === "track" ? "Target berada dalam jalur." : p.forecastMonths ? `Perkiraan tercapai ${p.forecastLabel}.` : "Atur deadline atau kontribusi bulanan.";
    return `<div class="item"><div class="item-h"><button class="btn-reset strong" data-act="editGoal" data-id="${g.id}">${esc(g.name)}</button><span>${badge(PRIORITIES[g.priority], g.priority === "high" ? "bad" : g.priority === "medium" ? "warn" : "neutral")}</span></div>
  ${bar(p.progress, p.status === "short" || p.status === "overdue" ? "warn" : "ok", g.name)}<div class="small muted">${money(p.current)} / ${money(g.target)} \xB7 ${pct(p.progress, 0)}</div><div class="small">${msg}</div>
  ${full ? `<div class="btn-row sm"><button class="btn ghost sm" data-act="contribute" data-id="${g.id}">Setor</button></div>` : ""}</div>`;
  }
  var F = { q: "", type: "all", acc: "", cat: "", month: "", sort: "new" };
  function txPage() {
    const accs = S.accounts.map((a) => `<option value="${a.id}" ${F.acc === a.id ? "selected" : ""}>${esc(a.name)}</option>`).join("");
    const cats = S.categories.map((c) => `<option value="${c.id}" ${F.cat === c.id ? "selected" : ""}>${esc(c.name)}</option>`).join("");
    const months = [...new Set(S.transactions.map((t) => t.date.slice(0, 7)))].sort().reverse().map((m) => `<option value="${m}" ${F.month === m ? "selected" : ""}>${monthLabel(m)}</option>`).join("");
    const html = `<div class="search"><input id="q" type="search" placeholder="Cari catatan, kategori, akun\u2026" aria-label="Cari transaksi" value="${esc(F.q)}"></div>
  <div class="chips" role="group" aria-label="Tipe">${[["all", "Semua"], ["income", "Income"], ["expense", "Expense"], ["transfer", "Transfer"]].map(([v, l]) => `<button class="chip ${F.type === v ? "on" : ""}" data-ftype="${v}" aria-pressed="${F.type === v}">${l}</button>`).join("")}</div>
  <div class="filters"><select id="fa" aria-label="Akun"><option value="">Semua akun</option>${accs}</select><select id="fc" aria-label="Kategori"><option value="">Semua kategori</option>${cats}</select><select id="fm" aria-label="Bulan"><option value="">Semua bulan</option>${months}</select><select id="fs" aria-label="Urutkan"><option value="new" ${F.sort === "new" ? "selected" : ""}>Terbaru</option><option value="old" ${F.sort === "old" ? "selected" : ""}>Terlama</option><option value="big" ${F.sort === "big" ? "selected" : ""}>Nominal terbesar</option></select></div>
  <div id="txlist"></div>`;
    return { title: "Transaksi", html, mount: (root) => {
      const draw = () => {
        const q = F.q.toLowerCase();
        let l = S.transactions.filter((t) => (F.type === "all" || t.type === F.type) && (!F.acc || t.accountId === F.acc || t.toAccountId === F.acc) && (!F.cat || t.categoryId === F.cat) && (!F.month || t.date.startsWith(F.month)) && (!q || [t.note, catLabel(t), accName(t.accountId)].join(" ").toLowerCase().includes(q)));
        l.sort(F.sort === "big" ? (a, b) => b.amount - a.amount : F.sort === "old" ? (a, b) => a.date.localeCompare(b.date) : (a, b) => b.date.localeCompare(a.date) || b.createdAt.localeCompare(a.createdAt));
        $("#txlist", root).innerHTML = !S.transactions.length ? empty("Belum ada transaksi.", "Mulai dengan mencatat pemasukan atau pengeluaran pertama Anda.", '<button class="btn primary" data-act="addTx">Catat transaksi</button>') : !l.length ? empty("Tidak ada hasil.", "Ubah kata kunci atau filter.") : F.sort === "big" ? `<div class="list">${l.map(txRow).join("")}</div>` : F.sort === "old" ? dayGroupAsc(l) : dayGroup(l);
      };
      $("#q", root).oninput = (e) => {
        F.q = e.target.value;
        draw();
      };
      $$("[data-ftype]", root).forEach((b) => b.onclick = () => {
        F.type = b.dataset.ftype;
        $$("[data-ftype]", root).forEach((x) => {
          x.classList.toggle("on", x === b);
          x.setAttribute("aria-pressed", x === b);
        });
        draw();
      });
      [["fa", "acc"], ["fc", "cat"], ["fm", "month"], ["fs", "sort"]].forEach(([id, k]) => $("#" + id, root).onchange = (e) => {
        F[k] = e.target.value;
        draw();
      });
      draw();
    } };
  }
  var dayGroupAsc = (list) => {
    const by = {};
    list.forEach((t) => (by[t.date] ||= []).push(t));
    return Object.keys(by).sort().map((d) => `<div class="day-h">${dateShort(d)} \xB7 ${dayName(d)}</div><div class="list">${by[d].map(txRow).join("")}</div>`).join("");
  };
  function openTxSheet(editId = null, preset = {}) {
    if (!S.accounts.length) return openSheet("Catat transaksi", empty("Belum ada rekening.", "Tambahkan rekening (mis. Cash atau BRI) sebelum mencatat transaksi.", '<button class="btn primary" data-act="addAccount">Tambah rekening</button>'));
    const old = editId ? S.transactions.find((t) => t.id === editId) : null;
    const st = old ? { ...old } : { type: "expense", date: today(), accountId: S.settings.lastAccountId && accById(S, S.settings.lastAccountId) ? S.settings.lastAccountId : S.accounts[0].id, toAccountId: "", categoryId: "", sub: "", amount: 0, note: "", ...preset };
    const root = openSheet(old ? "Edit transaksi" : "Catat transaksi", '<div id="txf"></div>');
    const box = $("#txf", root);
    const read = () => {
      const g = (id) => $("#" + id, box);
      if (!g("t_amt")) return;
      st.amount = parseAmount(g("t_amt").value);
      st.accountId = g("t_acc").value;
      st.date = g("t_date").value;
      st.note = g("t_note").value.trim();
      if (g("t_to")) st.toAccountId = g("t_to").value;
    };
    const draw = () => {
      const kind = st.type, cats = S.categories.filter((c) => c.kind === kind), cur = catById(S, st.categoryId);
      const opts = (sel, skip) => S.accounts.filter((a) => a.id !== skip).map((a) => `<option value="${a.id}" ${a.id === sel ? "selected" : ""}>${esc(a.name)}</option>`).join("");
      if (kind === "transfer" && !st.toAccountId) st.toAccountId = (S.accounts.find((a) => a.id !== st.accountId && SAVING_TYPES.includes(a.type)) || S.accounts.find((a) => a.id !== st.accountId) || {}).id || "";
      box.innerHTML = `<div class="form-error" id="terr" role="alert"></div>
    <div class="seg" role="group" aria-label="Tipe transaksi">${[["expense", "Pengeluaran"], ["income", "Pemasukan"], ["transfer", "Transfer"]].map(([v, l]) => `<button type="button" class="${kind === v ? "on" : ""}" data-seg="${v}" aria-pressed="${kind === v}" ${old && old.type !== v ? "disabled" : ""}>${l}</button>`).join("")}</div>
    <div class="field"><label for="t_amt">Nominal (Rp)</label><input id="t_amt" class="amt" data-money inputmode="numeric" autocomplete="off" placeholder="0" value="${st.amount ? dots(st.amount) : ""}"></div>
    ${kind !== "transfer" ? `<div class="field"><label>Kategori</label><div class="chips wrap">${cats.map((c) => `<button type="button" class="chip ${st.categoryId === c.id ? "on" : ""}" data-cat="${c.id}" aria-pressed="${st.categoryId === c.id}">${esc(c.name)}</button>`).join("")}</div></div>
    ${cur?.subs?.length ? `<div class="field"><label>Subkategori</label><div class="chips wrap">${cur.subs.map((s) => `<button type="button" class="chip ${st.sub === s ? "on" : ""}" data-sub="${esc(s)}" aria-pressed="${st.sub === s}">${esc(s)}</button>`).join("")}</div></div>` : ""}` : ""}
    <div class="field"><label for="t_acc">${kind === "transfer" ? "Dari akun" : "Akun"}</label><select id="t_acc">${opts(st.accountId)}</select></div>
    ${kind === "transfer" ? `<div class="field"><label for="t_to">Ke akun</label><select id="t_to">${opts(st.toAccountId, st.accountId)}</select></div>` : ""}
    <div class="field"><label for="t_date">Tanggal</label><input id="t_date" type="date" value="${esc(st.date)}"></div>
    <div class="field"><label for="t_note">Catatan</label><input id="t_note" maxlength="120" placeholder="Opsional" value="${esc(st.note)}"></div>
    <div class="btn-row"><button class="btn primary" id="t_save">Simpan</button>${old ? '<button class="btn danger-o" id="t_del">Hapus</button>' : ""}</div>`;
      if (!old) $("#t_amt", box).focus({ preventScroll: true });
      $("#t_acc", box).onchange = () => {
        read();
        if (st.type === "transfer") {
          st.toAccountId = "";
        }
        draw();
      };
    };
    box.addEventListener("click", async (e) => {
      const b = e.target.closest("button");
      if (!b) return;
      if (b.dataset.seg) {
        read();
        if (st.type !== b.dataset.seg) {
          st.type = b.dataset.seg;
          st.categoryId = "";
          st.sub = "";
          st.toAccountId = "";
        }
        draw();
      } else if (b.dataset.cat) {
        read();
        st.categoryId = b.dataset.cat;
        st.sub = "";
        draw();
      } else if (b.dataset.sub !== void 0) {
        read();
        st.sub = st.sub === b.dataset.sub ? "" : b.dataset.sub;
        draw();
      } else if (b.id === "t_save") {
        read();
        const r = await saveTx(st, editId);
        if (r.error) {
          $("#terr", box).textContent = r.error;
          return;
        }
        closeSheet();
        toast(old ? "Transaksi diperbarui." : "Transaksi disimpan.");
      } else if (b.id === "t_del") {
        if (await confirmBox({ title: "Hapus transaksi?", message: "Saldo akun akan dihitung ulang.", okText: "Hapus", danger: true })) {
          await remove("transactions", editId);
          closeSheet();
          toast("Transaksi dihapus.");
        }
      }
    });
    draw();
  }
  var budgetMonth = curMonth();
  function budgetPage() {
    const bu = budgetUsage(S, budgetMonth), tb = sum(bu, (b) => b.amount), ta = sum(bu, (b) => b.actual), p = tb ? ta / tb * 100 : 0;
    const html = `<div class="monthnav"><button class="icon-btn" data-act="bMonth" data-d="-1" aria-label="Bulan sebelumnya">\u2039</button><strong>${monthLabel(budgetMonth)}</strong><button class="icon-btn" data-act="bMonth" data-d="1" aria-label="Bulan berikutnya">\u203A</button></div>
  ${bu.length ? `<div class="card"><div class="lbl">Total budget</div><div class="big sm">${money(ta)} <span class="muted">/ ${money(tb)}</span></div>${bar(p, p > 100 ? "over" : p >= 80 ? "warn" : "ok", "Total budget")}<div class="small muted">${pct(p, 0)} terpakai \xB7 ${tb - ta >= 0 ? "Sisa " + money(tb - ta) : "Melebihi " + money(ta - tb)}</div></div>
  <div class="card">${bu.sort((a, b) => b.pct - a.pct).map(budgetItem).join("")}</div>` : empty("Belum ada budget.", "Tentukan batas bulanan per kategori untuk memantau pengeluaran.")}
  <button class="btn primary block" data-act="addBudget">Tambah budget</button>`;
    return { title: "Budget", html };
  }
  function budgetSheet(id = null) {
    const b = id ? S.budgets.find((x) => x.id === id) : null;
    const opts = [];
    S.categories.filter((c) => c.kind === "expense").forEach((c) => {
      opts.push([c.id + "|", `${c.name} (semua)`]);
      c.subs.forEach((s) => opts.push([c.id + "|" + s, `${c.name} \u203A ${s}`]));
    });
    formSheet({
      title: b ? "Edit budget" : "Tambah budget",
      intro: "Budget berlaku setiap bulan.",
      fields: [{ id: "target", label: "Kategori", type: "select", options: opts, value: b ? b.categoryId + "|" + (b.sub || "") : opts[0]?.[0] }, { id: "amount", label: "Budget bulanan (Rp)", type: "money", value: b?.amount }],
      onSubmit: async (v) => {
        if (!(v.amount > 0)) return "Nominal harus lebih besar dari Rp0.";
        const [categoryId, sub] = v.target.split("|");
        if (S.budgets.some((x) => x.id !== id && x.categoryId === categoryId && (x.sub || "") === sub)) return "Budget untuk kategori ini sudah ada.";
        await save("budgets", { ...b || {}, id: id || uid("bud"), categoryId, sub, amount: v.amount });
        toast("Budget disimpan.");
      },
      onDelete: b ? async () => {
        await remove("budgets", id);
      } : null
    });
  }
  function goalsPage() {
    const ef = emergency(S);
    const order = { high: 0, medium: 1, low: 2 };
    const goals = S.goals.filter((g) => !g.isEmergency).sort((a, b) => order[a.priority] - order[b.priority]);
    const html = `<button class="card block btn-reset" data-nav="emergency"><div class="card-h"><h3>Dana Darurat</h3>${badge("HIGH", "bad")}</div>
    ${ef.target > 0 ? `${bar(ef.progress, "ok", "Dana darurat")}<div class="small muted">${money(ef.current)} / ${money(ef.target)} \xB7 Cakupan ${ef.coverage.toFixed(1).replace(".", ",")} dari ${ef.months} bulan</div>` : '<p class="small muted">Atur pengeluaran wajib dan target bulan.</p>'}</button>
  ${goals.length ? `<div class="card">${goals.map((g) => goalItem(g)).join("")}</div>` : empty("Belum ada target.", "Buat target seperti Laptop, Motor, atau Pendidikan.")}
  <button class="btn primary block" data-act="addGoal">Tambah target</button>`;
    return { title: "Target", html };
  }
  function goalSheet(id = null) {
    const g = id ? S.goals.find((x) => x.id === id) : null;
    formSheet({
      title: g ? "Edit target" : "Tambah target",
      fields: [
        { id: "name", label: "Nama target", type: "text", value: g?.name, placeholder: "mis. Laptop" },
        { id: "target", label: "Target nominal (Rp)", type: "money", value: g?.target },
        { id: "start", label: "Dana saat ini / awal (Rp)", type: "money", value: g?.start, hint: "Setoran yang dicatat lewat tombol Setor ditambahkan otomatis." },
        { id: "deadline", label: "Deadline (opsional)", type: "date", value: g?.deadline },
        { id: "priority", label: "Prioritas", type: "select", options: Object.entries(PRIORITIES), value: g?.priority || "medium" },
        { id: "monthly", label: "Kontribusi bulanan (Rp)", type: "money", value: g?.monthly }
      ],
      onSubmit: async (v) => {
        if (!v.name) return "Nama target wajib diisi.";
        const cur = (v.start || 0) + (g ? goalCurrent(S, g) - (g.start || 0) : 0);
        if (!(v.target > cur)) return "Target harus lebih besar dari nilai saat ini.";
        if (v.deadline && !validDate(v.deadline)) return "Tanggal tidak valid.";
        await save("goals", { ...g || { createdAt: now() }, id: id || uid("goal"), name: v.name, target: v.target, start: v.start || 0, deadline: v.deadline, priority: v.priority, monthly: v.monthly || 0 });
        toast("Target disimpan.");
      },
      onDelete: g ? async () => {
        if (g.isEmergency) return "Dana Darurat diatur lewat menu Dana Darurat.";
        if (S.transactions.some((t) => t.goalId === id)) return "Target sudah memiliki setoran. Hapus transaksinya lebih dulu.";
        await remove("goals", id);
      } : null
    });
  }
  function contributeSheet(id) {
    const g = S.goals.find((x) => x.id === id);
    if (!g) return toast("Target tidak ditemukan.");
    if (S.accounts.length < 2) return toast("Buat rekening tujuan (mis. Tabungan) di menu Rekening dulu.");
    const to = (S.accounts.find((a) => SAVING_TYPES.includes(a.type)) || S.accounts[1]).id, accs = S.accounts.map((a) => [a.id, a.name]);
    formSheet({
      title: "Setor ke " + g.name,
      intro: "Dicatat sebagai transfer antar akun, sehingga bukan pengeluaran.",
      submitText: "Setor",
      fields: [{ id: "amount", label: "Nominal (Rp)", type: "money" }, { id: "from", label: "Dari akun", type: "select", options: accs, value: S.settings.lastAccountId || S.accounts[0].id }, { id: "to", label: "Ke akun", type: "select", options: accs, value: to }, { id: "date", label: "Tanggal", type: "date", value: today() }],
      onSubmit: async (v) => {
        const r = await contributeGoal(g, { amount: v.amount, accountId: v.from, toAccountId: v.to, date: v.date });
        if (r.error) return r.error;
        toast("Setoran dicatat.");
      }
    });
  }
  function morePage() {
    const grp = (title, items) => `<div class="card"><div class="card-h"><h3>${title}</h3></div><div class="list flush">${items.map(([k, l, d]) => `<button class="row" data-nav="${k}"><div class="row-main"><div class="row-t">${l}</div><div class="row-s">${d}</div></div><span class="chev">\u203A</span></button>`).join("")}</div></div>`;
    return { title: "Lainnya", html: grp("Kelola", [["accounts", "Rekening", "Cash, bank, e-wallet, tabungan"], ["assets", "Aset", "Net worth dan aset non-cash"], ["debts", "Utang", "Cicilan dan pinjaman"], ["recurring", "Transaksi berulang", "Gaji, tagihan, cicilan"], ["emergency", "Dana darurat", "Cakupan dan target"]]) + grp("Analisis", [["reports", "Laporan", "Income, expense, budget, net worth, utang, target"], ["cashflow", "Cash flow", "Pemasukan vs pengeluaran"], ["calendar", "Kalender & heatmap", "Transaksi dan pengeluaran per hari"], ["review", "Monthly review", "Ringkasan dan perbandingan bulan"], ["annual", "Ringkasan tahunan", "Performa satu tahun"], ["scenarios", "Skenario & mode", "Reality, Conservative, Stable, Growth"]]) + grp("Aplikasi", [["settings", "Pengaturan", "Profil, tema, keamanan, kategori"], ["backup", "Backup & restore", "Export, import, reset"], ["about", "Tentang", "Chem Studio"]]) };
  }
  var ACT = {
    addTx: () => openTxSheet(),
    editTx: (el) => openTxSheet(el.dataset.id),
    addBudget: () => budgetSheet(),
    editBudget: (el) => budgetSheet(el.dataset.id),
    bMonth: (el, rerender) => {
      budgetMonth = addMonths(budgetMonth, +el.dataset.d);
      rerender();
    },
    addGoal: () => goalSheet(),
    editGoal: (el) => goalSheet(el.dataset.id),
    contribute: (el) => contributeSheet(el.dataset.id),
    healthInfo: () => {
      const hs = healthScore(S);
      openSheet("Health Score", `<p class="muted small">Skor sederhana dari data Anda di aplikasi ini \u2014 bukan skor finansial resmi.</p><div class="score big"><span class="score-n">${hs.total ?? "\u2014"}</span><span class="muted">/ 100</span>${badge(hs.status, "neutral")}</div>${hs.comps.map((c) => `<div class="item"><div class="item-h"><span>${c.label}</span><span>${c.score == null ? "\u2014" : c.score + "/100"}</span></div>${bar(c.score || 0, c.score >= 70 ? "ok" : c.score >= 40 ? "warn" : "over", c.label)}<div class="small muted">${esc(c.note)}</div></div>`).join("")}`);
    }
  };

  // js/views-manage.js
  function accountsPage() {
    const b = balances(S);
    const groups = Object.entries(ACCOUNT_TYPES).map(([k, label]) => {
      const l = S.accounts.filter((a) => a.type === k);
      if (!l.length) return "";
      return `<div class="card"><div class="card-h"><h3>${label}</h3><span class="muted small">${money(sum(l, (a) => b[a.id] || 0))}</span></div><div class="list flush">${l.map((a) => `<button class="row" data-act="editAccount" data-id="${a.id}"><div class="row-main"><div class="row-t">${esc(a.name)}</div>${a.note ? `<div class="row-s">${esc(a.note)}</div>` : ""}</div><div class="row-amt">${money(b[a.id] || 0)}</div></button>`).join("")}</div></div>`;
    }).join("");
    return { title: "Rekening", html: `<div class="card stat"><div class="lbl">Total saldo semua rekening</div><div class="val">${money(totalBalance(S))}</div></div>${groups || empty("Belum ada rekening.", "Tambahkan rekening seperti Cash, BRI, atau DANA.")}<button class="btn primary block" data-act="addAccount">Tambah rekening</button>` };
  }
  function accountSheet(id = null) {
    const a = id ? accById(S, id) : null;
    formSheet({
      title: a ? "Edit rekening" : "Tambah rekening",
      fields: [
        { id: "name", label: "Nama", type: "text", value: a?.name, placeholder: "mis. BRI, Cash, DANA" },
        { id: "type", label: "Jenis", type: "select", options: Object.entries(ACCOUNT_TYPES), value: a?.type || "bank" },
        { id: "opening", label: "Saldo awal (Rp)", type: "money", value: a?.openingBalance, hint: a ? `Saldo berjalan: ${rp(balances(S)[a.id] || 0)}. Mengubah saldo awal ikut mengubah saldo berjalan.` : "Saldo berjalan dihitung dari saldo awal + transaksi." },
        { id: "note", label: "Catatan", type: "text", value: a?.note }
      ],
      onSubmit: async (v) => {
        if (!v.name) return "Nama rekening wajib diisi.";
        if (S.accounts.some((x) => x.id !== id && x.name.toLowerCase() === v.name.toLowerCase())) return "Nama rekening sudah dipakai.";
        await save("accounts", { ...a || { createdAt: now() }, id: id || uid("acc"), name: v.name, type: v.type, openingBalance: v.opening || 0, note: v.note });
        toast("Rekening disimpan.");
      },
      onDelete: a ? async () => (await deleteAccount(id)).error : null
    });
  }
  function assetsPage() {
    const h = netWorthHistory(S), b = balances(S);
    const html = `<div class="card hero"><div class="lbl">Net worth = Aset \u2212 Utang</div><div class="big">${money(netWorth(S))}</div><div class="hero-sub"><span>Aset ${money(totalAssets(S))}</span><span>Utang ${money(totalDebt(S))}</span></div></div>
  <div class="card"><div class="card-h"><h3>Perkembangan net worth</h3></div>${h.length > 1 ? lineChart(h.map((x) => monthLabel(x.mk).slice(0, 3)), h.map((x) => x.value)) : '<p class="muted small">Grafik muncul setelah ada data lebih dari satu bulan.</p>'}<p class="hint">Aset non-cash dan utang memakai nilai terkini.</p></div>
  <div class="card"><div class="card-h"><h3>Rekening</h3><button class="link" data-nav="accounts">Kelola</button></div><div class="list flush">${S.accounts.map((a) => `<div class="row static"><div class="row-main"><div class="row-t">${esc(a.name)}</div><div class="row-s">${ACCOUNT_TYPES[a.type]}</div></div><div class="row-amt">${money(b[a.id] || 0)}</div></div>`).join("") || '<p class="muted small">Belum ada rekening.</p>'}</div></div>
  <div class="card"><div class="card-h"><h3>Aset non-cash</h3></div>${S.assets.length ? `<div class="list flush">${S.assets.map((a) => `<button class="row" data-act="editAsset" data-id="${a.id}"><div class="row-main"><div class="row-t">${esc(a.name)}</div><div class="row-s">${esc(a.type)} \xB7 estimasi nilai</div></div><div class="row-amt">${money(a.value)}</div></button>`).join("")}</div>` : '<p class="muted small">Kendaraan, properti, deposito, atau investasi yang tidak ada di rekening.</p>'}</div>
  <button class="btn primary block" data-act="addAsset">Tambah aset</button>`;
    return { title: "Aset", html };
  }
  function assetSheet(id = null) {
    const a = id ? S.assets.find((x) => x.id === id) : null;
    formSheet({
      title: a ? "Edit aset" : "Tambah aset",
      fields: [{ id: "name", label: "Nama aset", type: "text", value: a?.name, placeholder: "mis. Motor" }, { id: "type", label: "Jenis", type: "select", options: ASSET_TYPES.map((t) => [t, t]), value: a?.type || "Aset lain" }, { id: "value", label: "Nilai / estimasi (Rp)", type: "money", value: a?.value, hint: "Untuk kendaraan atau properti, isi estimasi nilai pasar." }],
      onSubmit: async (v) => {
        if (!v.name) return "Nama aset wajib diisi.";
        if (!(v.value > 0)) return "Nominal harus lebih besar dari Rp0.";
        await save("assets", { ...a || {}, id: id || uid("ast"), name: v.name, type: v.type, value: v.value, updatedAt: now() });
        toast("Aset disimpan.");
      },
      onDelete: a ? async () => {
        await remove("assets", id);
      } : null
    });
  }
  function debtsPage() {
    const L = S.liabilities, orig = sum(L, (l) => l.original), rem = sum(L, (l) => liabilityRemaining(S, l)), paid = orig - rem;
    const item = (l) => {
      const r = liabilityRemaining(S, l), p = l.original ? (l.original - r) / l.original * 100 : 0;
      return `<div class="item"><div class="item-h"><button class="btn-reset strong" data-act="editDebt" data-id="${l.id}">${esc(l.name)}</button>${badge(l.status === "lunas" ? "Lunas" : l.type, l.status === "lunas" ? "good" : "neutral")}</div>${bar(p, "ok", l.name)}
    <div class="small muted">Sisa ${money(r)} dari ${money(l.original)} \xB7 ${pct(p, 0)} terbayar</div><div class="small muted">${l.installment ? "Cicilan " + money(l.installment) : ""}${l.dueDay ? " \xB7 jatuh tempo tanggal " + l.dueDay : ""}${l.interest ? " \xB7 bunga " + String(l.interest).replace(".", ",") + "%" : ""}</div>
    ${l.status !== "lunas" ? `<div class="btn-row sm"><button class="btn ghost sm" data-act="payDebt" data-id="${l.id}">Bayar</button></div>` : ""}</div>`;
    };
    return { title: "Utang", html: `<div class="grid2 three"><div class="card stat"><div class="lbl">Total utang</div><div class="val">${money(orig)}</div></div><div class="card stat"><div class="lbl">Terbayar</div><div class="val pos">${money(paid)}</div></div><div class="card stat"><div class="lbl">Sisa utang</div><div class="val neg">${money(rem)}</div></div></div>
  ${L.length ? `<div class="card">${L.map(item).join("")}</div>` : empty("Belum ada utang tercatat.", "Catat cicilan atau pinjaman untuk memantau sisa dan jatuh tempo.")}<button class="btn primary block" data-act="addDebt">Tambah utang</button>` };
  }
  function debtSheet(id = null) {
    const l = id ? S.liabilities.find((x) => x.id === id) : null;
    formSheet({
      title: l ? "Edit utang" : "Tambah utang",
      fields: [
        { id: "name", label: "Nama utang", type: "text", value: l?.name, placeholder: "mis. Cicilan HP" },
        { id: "type", label: "Jenis", type: "select", options: DEBT_TYPES.map((t) => [t, t]), value: l?.type || "Cicilan" },
        { id: "original", label: "Nilai awal (Rp)", type: "money", value: l?.original },
        { id: "remaining", label: "Sisa utang saat dicatat (Rp)", type: "money", value: l?.remaining, hint: "Pembayaran lewat tombol Bayar mengurangi sisa otomatis." },
        { id: "installment", label: "Cicilan per bulan (Rp)", type: "money", value: l?.installment },
        { id: "dueDay", label: "Jatuh tempo (tanggal 1\u201331)", type: "number", min: 1, max: 31, step: 1, value: l?.dueDay },
        { id: "interest", label: "Bunga % (opsional)", type: "number", value: l?.interest }
      ],
      onSubmit: async (v) => {
        if (!v.name) return "Nama utang wajib diisi.";
        if (!(v.original > 0)) return "Nominal harus lebih besar dari Rp0.";
        if (v.remaining > v.original) return "Sisa utang tidak boleh melebihi nilai awal.";
        if (v.dueDay != null && (v.dueDay < 1 || v.dueDay > 31)) return "Tanggal jatuh tempo harus 1\u201331.";
        await save("liabilities", { ...l || {}, id: id || uid("lia"), name: v.name, type: v.type, original: v.original, remaining: v.remaining ?? v.original, installment: v.installment || 0, dueDay: v.dueDay ? Math.round(v.dueDay) : null, interest: v.interest || 0, status: (v.remaining ?? v.original) === 0 ? "lunas" : l?.status === "lunas" ? "aktif" : l?.status || "aktif" });
        toast("Utang disimpan.");
      },
      onDelete: l ? async () => {
        if (S.transactions.some((t) => t.liabilityId === id)) return "Utang sudah memiliki pembayaran. Hapus transaksinya lebih dulu.";
        await remove("liabilities", id);
      } : null
    });
  }
  function payDebtSheet(id) {
    const l = S.liabilities.find((x) => x.id === id);
    if (!S.accounts.length) return toast("Tambahkan rekening dulu.");
    formSheet({
      title: "Bayar " + l.name,
      intro: "Dicatat sebagai pengeluaran dan mengurangi sisa utang.",
      submitText: "Catat pembayaran",
      fields: [{ id: "amount", label: "Nominal (Rp)", type: "money", value: Math.min(l.installment || 0, liabilityRemaining(S, l)) || "" }, { id: "acc", label: "Dari akun", type: "select", options: S.accounts.map((a) => [a.id, a.name]), value: S.settings.lastAccountId || S.accounts[0].id }, { id: "date", label: "Tanggal", type: "date", value: today() }],
      onSubmit: async (v) => {
        const r = await payDebt(l, { amount: v.amount, accountId: v.acc, date: v.date });
        if (r.error) return r.error;
        toast("Pembayaran dicatat.");
      }
    });
  }
  function recurringPage() {
    const l = S.recurring.map((r) => `<div class="row static"><div class="row-main"><div class="row-t">${esc(r.name)}</div><div class="row-s">Setiap tanggal ${r.day} \xB7 ${esc(S.accounts.find((a) => a.id === r.accountId)?.name || "\u2014")} \xB7 ${esc(catName(S, r.categoryId))}</div></div>
    <div class="row-end"><div class="row-amt ${r.type === "income" ? "pos" : "neg"}">${money(r.amount)}</div><label class="switch"><input type="checkbox" data-act="toggleRec" data-id="${r.id}" ${r.active ? "checked" : ""} aria-label="Aktif: ${esc(r.name)}"><span></span></label><button class="link" data-act="editRec" data-id="${r.id}">Edit</button></div></div>`).join("");
    return { title: "Berulang", html: `<p class="muted small">Transaksi berulang dibuat otomatis saat aplikasi dibuka pada atau setelah tanggalnya. PWA tidak bisa menjalankan tugas di latar belakang saat tertutup.</p>
  ${l ? `<div class="card"><div class="list flush">${l}</div></div>` : empty("Belum ada transaksi berulang.", "Tambahkan gaji, kos, internet, atau cicilan.")}<button class="btn primary block" data-act="addRec">Tambah transaksi berulang</button>` };
  }
  function recurringSheet(id = null) {
    const r = id ? S.recurring.find((x) => x.id === id) : null;
    if (!S.accounts.length) return toast("Tambahkan rekening dulu.");
    const opts = [];
    S.categories.forEach((c) => {
      if (c.kind === "income") opts.push([c.id + "|", `${c.name} (pemasukan)`]);
      else {
        opts.push([c.id + "|", c.name]);
        c.subs.forEach((s) => opts.push([c.id + "|" + s, `${c.name} \u203A ${s}`]));
      }
    });
    formSheet({
      title: r ? "Edit berulang" : "Tambah berulang",
      fields: [
        { id: "name", label: "Nama", type: "text", value: r?.name, placeholder: "mis. Internet" },
        { id: "cat", label: "Kategori (menentukan pemasukan/pengeluaran)", type: "select", options: opts, value: r ? r.categoryId + "|" + (r.sub || "") : opts[0][0] },
        { id: "amount", label: "Nominal (Rp)", type: "money", value: r?.amount },
        { id: "acc", label: "Akun", type: "select", options: S.accounts.map((a) => [a.id, a.name]), value: r?.accountId || S.accounts[0].id },
        { id: "day", label: "Tanggal setiap bulan (1\u201331)", type: "number", min: 1, max: 31, step: 1, value: r?.day }
      ],
      onSubmit: async (v) => {
        if (!v.name) return "Nama wajib diisi.";
        if (!(v.amount > 0)) return "Nominal harus lebih besar dari Rp0.";
        if (!(v.day >= 1 && v.day <= 31)) return "Tanggal harus 1\u201331.";
        const [categoryId, sub] = v.cat.split("|"), type = catById(S, categoryId).kind, mk = today().slice(0, 7), dayNow = +today().slice(8);
        const lastRun = r ? r.lastRun : Math.round(v.day) <= dayNow ? mk : (() => {
          const d = /* @__PURE__ */ new Date();
          d.setMonth(d.getMonth() - 1, 1);
          return d.toISOString().slice(0, 7);
        })();
        await save("recurring", { ...r || {}, id: id || uid("rec"), name: v.name, type, categoryId, sub, amount: v.amount, accountId: v.acc, day: Math.round(v.day), active: r ? r.active : true, lastRun });
        toast("Disimpan.");
      },
      onDelete: r ? async () => {
        await remove("recurring", id);
      } : null
    });
  }
  function emergencyPage() {
    const e = emergency(S), cov = e.coverage.toFixed(1).replace(".", ",");
    const html = `<div class="card hero"><div class="lbl">Cakupan dana darurat</div><div class="big">${cov} <span class="muted">dari ${e.months || 0} bulan</span></div>${bar(e.progress, "ok", "Dana darurat")}<div class="small muted">${money(e.current)} dari target ${money(e.target)} (${pct(e.progress, 0)})</div></div>
  <div class="card"><div class="item-h"><span>Pengeluaran wajib / bulan</span><strong>${money(e.mandatory)}</strong></div><div class="item-h"><span>Target jumlah bulan</span><strong>${e.months || 0} bulan</strong></div><div class="item-h"><span>Target dana darurat</span><strong>${money(e.target)}</strong></div><div class="item-h"><span>Dana saat ini</span><strong>${money(e.current)}</strong></div>
  <div class="btn-row"><button class="btn ghost" data-act="editEf">Ubah pengaturan</button><button class="btn primary" data-act="contribute" data-id="${e.goal?.id}">Setor</button></div></div>
  <p class="hint">Dana darurat bertambah lewat tombol Setor (transfer ke rekening tabungan). Nilai awal bisa diubah di Target \u2192 Dana Darurat.</p>`;
    return { title: "Dana Darurat", html };
  }
  function efSheet() {
    formSheet({
      title: "Pengaturan dana darurat",
      fields: [{ id: "m", label: "Pengeluaran wajib per bulan (Rp)", type: "money", value: S.profile?.mandatoryExpense }, { id: "n", label: "Target jumlah bulan", type: "number", min: 1, max: 36, step: 1, value: S.profile?.efMonths || 6 }, { id: "start", label: "Dana darurat awal (Rp)", type: "money", value: S.goals.find((g) => g.isEmergency)?.start }],
      onSubmit: async (v) => {
        if (!(v.m > 0)) return "Nominal harus lebih besar dari Rp0.";
        if (!(v.n >= 1)) return "Target bulan minimal 1.";
        await saveProfile({ mandatoryExpense: v.m, efMonths: Math.round(v.n) });
        const g = S.goals.find((x) => x.isEmergency);
        if (g) await save("goals", { ...g, start: v.start || 0 });
        await syncEmergencyTarget();
        toast("Disimpan.");
      }
    });
  }
  var ACT2 = {
    addAccount: () => accountSheet(),
    editAccount: (el) => accountSheet(el.dataset.id),
    addAsset: () => assetSheet(),
    editAsset: (el) => assetSheet(el.dataset.id),
    addDebt: () => debtSheet(),
    editDebt: (el) => debtSheet(el.dataset.id),
    payDebt: (el) => payDebtSheet(el.dataset.id),
    addRec: () => recurringSheet(),
    editRec: (el) => recurringSheet(el.dataset.id),
    toggleRec: async (el) => {
      const r = S.recurring.find((x) => x.id === el.dataset.id);
      await save("recurring", { ...r, active: el.checked });
    },
    editEf: () => efSheet()
  };

  // js/views-analysis.js
  var monthNav = (mk, act) => `<div class="monthnav"><button class="icon-btn" data-act="${act}" data-d="-1" aria-label="Bulan sebelumnya">\u2039</button><strong>${monthLabel(mk)}</strong><button class="icon-btn" data-act="${act}" data-d="1" aria-label="Bulan berikutnya">\u203A</button></div>`;
  var seg = (items, cur, act) => `<div class="seg" role="group">${items.map(([v, l]) => `<button class="${cur === v ? "on" : ""}" data-act="${act}" data-v="${v}" aria-pressed="${cur === v}">${l}</button>`).join("")}</div>`;
  var share = (entries, total) => entries.map(([name, v]) => `<div class="item"><div class="item-h"><span>${esc(name)}</span><span>${pct(total ? v / total * 100 : 0, 0)}</span></div>${bar(total ? v / total * 100 : 0, "ok", name)}<div class="small muted">${money(v)}</div></div>`).join("");
  var R = { tab: "income", mk: curMonth() };
  function reportsPage() {
    const tabs = [["income", "Income"], ["expense", "Expense"], ["budget", "Budget"], ["networth", "Net worth"], ["debt", "Utang"], ["goal", "Target"]];
    const st = monthStats(S, R.mk);
    let body = "";
    if (R.tab === "income") {
      const t = S.profile?.monthlyIncome || 0, p = t ? st.income / t * 100 : 0;
      body = `<div class="card"><div class="item-h"><span>Actual income</span><strong class="pos">${money(st.income)}</strong></div>${t ? `<div class="item-h"><span>Target income</span><strong>${money(t)}</strong></div>${bar(p, p >= 100 ? "ok" : "warn", "Income vs target")}<div class="small muted">${pct(p, 0)} dari target</div>` : '<p class="small muted">Target income belum diatur (Pengaturan \u2192 Profil).</p>'}</div>
    <div class="card"><div class="card-h"><h3>Rincian pemasukan</h3></div>${st.income ? share(Object.entries(st.incByCat).map(([id, v]) => [catName(S, id), v]).sort((a, b) => b[1] - a[1]), st.income) : '<p class="muted small">Belum ada pemasukan bulan ini.</p>'}</div>`;
    } else if (R.tab === "expense") {
      const cats = Object.entries(st.byCat).map(([id, v]) => [catName(S, id), v]).sort((a, b) => b[1] - a[1]);
      const subs = Object.entries(st.bySub).map(([k, v]) => {
        const [c, s] = k.split("|");
        return [s ? `${catName(S, c)} \u203A ${s}` : catName(S, c), v];
      }).sort((a, b) => b[1] - a[1]).slice(0, 8);
      body = st.expense ? `<div class="card"><div class="item-h"><span>Total pengeluaran</span><strong class="neg">${money(st.expense)}</strong></div></div><div class="card"><div class="card-h"><h3>Analisis kategori</h3></div>${share(cats, st.expense)}</div><div class="card"><div class="card-h"><h3>Rincian teratas</h3></div>${share(subs, st.expense)}</div>` : empty("Belum ada pengeluaran.", "Catat pengeluaran untuk melihat analisis kategori.");
    } else if (R.tab === "budget") {
      const bu = budgetUsage(S, R.mk);
      body = bu.length ? `<div class="card">${bu.sort((a, b) => b.pct - a.pct).map((b) => `<div class="item"><div class="item-h"><span>${esc(b.label)}</span><span>${pct(b.pct, 0)}</span></div>${bar(b.pct, b.state, b.label)}<div class="small ${b.state === "over" ? "neg" : "muted"}">${money(b.actual)} / ${money(b.amount)} \xB7 ${b.left >= 0 ? "Sisa " + money(b.left) : "Melebihi " + money(-b.left)}</div></div>`).join("")}</div>` : empty("Belum ada budget.", "Atur budget di tab Budget.");
    } else if (R.tab === "networth") {
      const h = netWorthHistory(S), b = balances(S), byType = {};
      S.accounts.forEach((a) => byType[ACCOUNT_TYPES[a.type]] = (byType[ACCOUNT_TYPES[a.type]] || 0) + (b[a.id] || 0));
      S.assets.forEach((a) => byType[a.type] = (byType[a.type] || 0) + a.value);
      body = `<div class="card hero"><div class="lbl">Net worth</div><div class="big">${money(netWorth(S))}</div></div><div class="card">${h.length > 1 ? lineChart(h.map((x) => MON3[+x.mk.slice(5) - 1]), h.map((x) => x.value)) : '<p class="muted small">Butuh data lebih dari satu bulan.</p>'}</div>
    <div class="card"><div class="card-h"><h3>Aset ${money(totalAssets(S))}</h3></div>${Object.entries(byType).filter(([, v]) => v).map(([k, v]) => `<div class="item-h"><span>${esc(k)}</span><span>${money(v)}</span></div>`).join("")}</div><div class="card"><div class="item-h"><h3>Utang</h3><strong class="neg">${money(totalDebt(S))}</strong></div></div>`;
    } else if (R.tab === "debt") {
      body = S.liabilities.length ? `<div class="card">${S.liabilities.map((l) => {
        const r = liabilityRemaining(S, l), p = l.original ? (l.original - r) / l.original * 100 : 0;
        return `<div class="item"><div class="item-h"><span>${esc(l.name)}</span><span>${pct(p, 0)}</span></div>${bar(p, "ok", l.name)}<div class="small muted">Sisa ${money(r)} dari ${money(l.original)}</div></div>`;
      }).join("")}</div>` : empty("Belum ada utang.", "Tambahkan utang di menu Utang.");
    } else {
      body = S.goals.length ? `<div class="card">${S.goals.map((g) => {
        const p = goalPlan(S, g);
        return `<div class="item"><div class="item-h"><span>${esc(g.name)}</span><span>${pct(p.progress, 0)}</span></div>${bar(p.progress, "ok", g.name)}<div class="small muted">${money(p.current)} / ${money(g.target)}${p.forecastLabel ? " \xB7 perkiraan " + p.forecastLabel : ""}</div></div>`;
      }).join("")}</div>` : empty("Belum ada target.", "Buat target di tab Target.");
    }
    return { title: "Laporan", html: `<div class="chips scroll">${tabs.map(([v, l]) => `<button class="chip ${R.tab === v ? "on" : ""}" data-act="rTab" data-v="${v}" aria-pressed="${R.tab === v}">${l}</button>`).join("")}</div>${["income", "expense", "budget"].includes(R.tab) ? monthNav(R.mk, "rMonth") : ""}${body}` };
  }
  var C = { range: "month", from: addMonths(curMonth(), -1) + "-01", to: today() };
  function cashflowPage() {
    const d = cashflowBuckets(S, C.range, C.from, C.to), net = d.totalIncome - d.totalExpense;
    const html = `${seg([["week", "Minggu"], ["month", "Bulan"], ["year", "Tahun"], ["custom", "Custom"]], C.range, "cfRange")}
  ${C.range === "custom" ? `<div class="grid2 tight"><div class="field"><label for="cf_from">Dari</label><input id="cf_from" type="date" value="${C.from}"></div><div class="field"><label for="cf_to">Sampai</label><input id="cf_to" type="date" value="${C.to}"></div></div><div class="form-error" id="cferr" role="alert"></div>` : ""}
  <div class="grid2 three"><div class="card stat"><div class="lbl">Income</div><div class="val pos">${money(d.totalIncome)}</div></div><div class="card stat"><div class="lbl">Expense</div><div class="val neg">${money(d.totalExpense)}</div></div><div class="card stat"><div class="lbl">Net</div><div class="val ${net >= 0 ? "pos" : "neg"}">${money(net)}</div></div></div>
  <div class="card">${d.labels.length ? groupedBars(d.labels, d.inc, d.exp) : '<p class="muted small">Periode tidak valid.</p>'}</div>
  ${C.range === "week" ? '<p class="hint">Tujuh hari terakhir, per hari.</p>' : C.range === "month" ? '<p class="hint">Bulan berjalan, per minggu.</p>' : ""}`;
    return { title: "Cash Flow", html, mount: (root) => {
      const f = $("#cf_from", root), t = $("#cf_to", root);
      if (f) [f, t].forEach((el) => el.onchange = () => {
        if (!validDate(f.value) || !validDate(t.value)) return;
        if (f.value > t.value) {
          $("#cferr", root).textContent = "Tanggal awal harus sebelum tanggal akhir.";
          return;
        }
        C.from = f.value;
        C.to = t.value;
        ACT3.rerender();
      });
    } };
  }
  var K = { mk: curMonth(), mode: "heat" };
  var billsOn = (mk, day) => [...S.recurring.filter((r) => r.active && clampDay(mk, r.day) === day).map((r) => ({ kind: "bill", text: r.name + " (berulang)", amount: r.amount })), ...S.liabilities.filter((l) => l.status !== "lunas" && l.dueDay && clampDay(mk, l.dueDay) === day).map((l) => ({ kind: "debt", text: "Jatuh tempo " + l.name, amount: l.installment }))];
  function calendarPage() {
    const n = daysInMonth(K.mk), st = monthStats(S, K.mk), off = (new Date(+K.mk.slice(0, 4), +K.mk.slice(5) - 1, 1).getDay() + 6) % 7;
    const per = {};
    st.txs.forEach((t) => {
      const d = +t.date.slice(8);
      const o = per[d] ||= { exp: 0, inc: 0, goal: false };
      if (t.type === "expense") o.exp += t.amount;
      if (t.type === "income") o.inc += t.amount;
      if (t.goalId) o.goal = true;
    });
    const max = Math.max(1, ...Object.values(per).map((o) => o.exp));
    let cells = "";
    for (let i = 0; i < off; i++) cells += "<span></span>";
    for (let d = 1; d <= n; d++) {
      const o = per[d] || { exp: 0, inc: 0 }, lvl = o.exp ? Math.ceil(o.exp / max * 4) : 0, bills = billsOn(K.mk, d), ds = `${K.mk}-${String(d).padStart(2, "0")}`;
      const marks = K.mode === "dots" ? `${o.inc ? '<i class="dot inc"></i>' : ""}${o.exp ? '<i class="dot exp"></i>' : ""}${bills.some((b) => b.kind === "bill") ? '<i class="dot bill"></i>' : ""}${bills.some((b) => b.kind === "debt") ? '<i class="dot debt"></i>' : ""}${o.goal ? '<i class="dot goal"></i>' : ""}` : "";
      cells += `<button class="day ${K.mode === "heat" ? "h" + lvl : ""} ${ds === today() ? "today" : ""}" data-act="dayDetail" data-d="${ds}" aria-label="${d} ${monthLabel(K.mk)}${o.exp ? ", pengeluaran " + short(o.exp) : ""}">${d}<span class="marks">${marks}</span></button>`;
    }
    const html = `${monthNav(K.mk, "kMonth")}${seg([["heat", "Heatmap"], ["dots", "Penanda"]], K.mode, "kMode")}<div class="cal"><span class="dow">Sen</span><span class="dow">Sel</span><span class="dow">Rab</span><span class="dow">Kam</span><span class="dow">Jum</span><span class="dow">Sab</span><span class="dow">Min</span>${cells}</div>
  ${K.mode === "heat" ? '<div class="legend"><span>Pengeluaran rendah</span><i class="sw h1"></i><i class="sw h2"></i><i class="sw h3"></i><i class="sw h4"></i><span>tinggi</span></div>' : '<div class="legend"><span><i class="dot inc"></i>Income</span><span><i class="dot exp"></i>Expense</span><span><i class="dot bill"></i>Tagihan</span><span><i class="dot debt"></i>Utang</span><span><i class="dot goal"></i>Setoran target</span></div>'}
  <p class="hint">Ketuk tanggal untuk melihat detail.</p>`;
    return { title: "Kalender", html };
  }
  function dayDetail(ds) {
    const txs = S.transactions.filter((t) => t.date === ds), bills = billsOn(ds.slice(0, 7), +ds.slice(8));
    openSheet(dateLong(ds), `${txs.length ? `<div class="list flush">${txs.map(txRow).join("")}</div>` : '<p class="muted small">Tidak ada transaksi.</p>'}${bills.length ? `<div class="card-h"><h3>Terjadwal</h3></div>${bills.map((b) => `<div class="item-h"><span>${esc(b.text)}</span><span>${money(b.amount)}</span></div>`).join("")}` : ""}<div class="btn-row"><button class="btn primary" data-act="addTxOn" data-d="${ds}">Catat transaksi</button></div>`);
  }
  function scenariosPage() {
    const mode = modeInfo(S.settings.mode), st = monthStats(S, curMonth());
    const focusSpend = sum(Object.entries(st.byCat).filter(([id]) => mode.cats.includes(catName(S, id))), ([, v]) => v);
    const goals = S.goals.filter((g) => goalPlan(S, g).status !== "done").sort((a, b) => "hml".indexOf(a.priority[0]) - "hml".indexOf(b.priority[0]));
    const card = (s) => {
      const net = s.income - s.expense - s.debt, rem = net - s.savings - s.investment, rate = s.income ? net / s.income * 100 : 0, mo = s.savings + s.investment, g = goals[0], p = g && mo > 0 ? Math.ceil(goalPlan(S, g).remaining / mo) : null;
      return `<div class="card"><div class="card-h"><h3>${esc(s.name)}</h3><button class="link" data-act="editScn" data-id="${s.id}">Edit</button></div>
    <div class="item-h"><span>Income</span><span>${money(s.income)}</span></div><div class="item-h"><span>Expense</span><span>${money(s.expense)}</span></div><div class="item-h"><span>Debt payment</span><span>${money(s.debt)}</span></div><div class="item-h"><span>Savings + Investment</span><span>${money(mo)}</span></div><hr>
    <div class="item-h"><strong>Net cash flow</strong><strong class="${net >= 0 ? "pos" : "neg"}">${money(net)}</strong></div><div class="item-h"><span>Sisa setelah alokasi</span><span>${money(rem)}</span></div><div class="item-h"><span>Saving rate</span><span>${pct(rate, 0)}</span></div>
    <div class="item-h"><span>Target ${g ? esc(g.name) : ""}</span><span>${p ? "\xB1 " + p + " bulan" : "\u2014"}</span></div></div>`;
    };
    const html = `<div class="card"><div class="card-h"><h3>Mode keuangan</h3></div>${seg([["survive", "SURVIVE"], ["stable", "STABLE"], ["grow", "GROW"]], S.settings.mode, "setMode")}
    <p class="small">Fokus ${mode.name}: ${mode.focus.join(", ")}.</p><p class="small muted">Pengeluaran bulan ini di area fokus: ${money(focusSpend)}${st.expense ? " (" + pct(focusSpend / st.expense * 100, 0) + " dari total)" : ""}.</p><p class="hint">Mode hanya membantu memahami kondisi, bukan nasihat keuangan profesional.</p></div>
  ${S.scenarios.length ? S.scenarios.map(card).join("") : empty("Belum ada skenario.", "Bandingkan Reality, Conservative, Stable, dan Growth untuk melihat arus kas dan target.", '<button class="btn primary" data-act="seedScn">Buat 4 skenario dari data saya</button>')}
  <button class="btn ${S.scenarios.length ? "primary" : "ghost"} block" data-act="addScn">Tambah skenario</button>`;
    return { title: "Skenario", html };
  }
  function scenarioSheet(id = null) {
    const s = id ? S.scenarios.find((x) => x.id === id) : null;
    formSheet({
      title: s ? "Edit skenario" : "Tambah skenario",
      fields: [{ id: "name", label: "Nama", type: "text", value: s?.name }, ...[["income", "Income / bulan"], ["expense", "Expense / bulan"], ["savings", "Savings / bulan"], ["investment", "Investment / bulan"], ["debt", "Debt payment / bulan"]].map(([k, l]) => ({ id: k, label: l + " (Rp)", type: "money", value: s?.[k] }))],
      onSubmit: async (v) => {
        if (!v.name) return "Nama skenario wajib diisi.";
        await save("scenarios", { ...s || {}, id: id || uid("scn"), name: v.name, income: v.income || 0, expense: v.expense || 0, savings: v.savings || 0, investment: v.investment || 0, debt: v.debt || 0 });
      },
      onDelete: s ? async () => {
        await remove("scenarios", id);
      } : null
    });
  }
  async function seedScenarios() {
    const ms = [0, -1, -2].map((i) => monthStats(S, addMonths(curMonth(), i))).filter((m) => m.count);
    const n = ms.length || 1;
    const inc = Math.round(sum(ms, (m) => m.income) / n) || S.profile?.monthlyIncome || 0, exp = Math.round(sum(ms, (m) => m.expense - m.debtPayment) / n) || S.profile?.mandatoryExpense || 0, debt = Math.round(sum(ms, (m) => m.debtPayment) / n), sav = Math.round(sum(ms, (m) => m.savings) / n);
    const mk = (name, income, expense, savings) => ({ id: uid("scn"), name, income, expense, savings, investment: 0, debt });
    for (const s of [mk("Reality", inc, exp, sav), mk("Conservative", inc, Math.round(exp * 0.8), Math.round(sav * 1.2)), mk("Stable", inc, exp, sav), mk("Growth", Math.round(inc * 1.2), exp, Math.round(sav * 1.5))]) await save("scenarios", s);
  }
  var V = { mk: curMonth() };
  function reviewPage() {
    const st = monthStats(S, V.mk), pv = monthStats(S, addMonths(V.mk, -1)), h = netWorthHistory(S), nw = (mk) => h.find((x) => x.mk === mk)?.value, d = nw(V.mk) != null && nw(addMonths(V.mk, -1)) != null ? nw(V.mk) - nw(addMonths(V.mk, -1)) : null;
    const well = [], watch = [];
    if (st.savingRate != null && pv.savingRate != null && st.savingRate > pv.savingRate) well.push(`Saving rate meningkat dari ${pct(pv.savingRate, 0)} menjadi ${pct(st.savingRate, 0)}.`);
    if (st.count && st.net >= 0) well.push("Cash flow bulan ini positif.");
    Object.entries(st.byCat).concat(Object.keys(pv.byCat).filter((k) => !(k in st.byCat)).map((k) => [k, 0])).forEach(([id, v]) => {
      const was = pv.byCat[id] || 0;
      if (was >= 5e4 && v < was * 0.9) well.push(`Pengeluaran ${catName(S, id)} turun ${pct((1 - v / was) * 100, 0)} dibanding bulan lalu.`);
      if (was >= 5e4 && v > was * 1.1) watch.push(`Pengeluaran ${catName(S, id)} naik ${pct((v / was - 1) * 100, 0)} dibanding bulan lalu.`);
    });
    const bu = budgetUsage(S, V.mk);
    if (bu.length && bu.every((b) => b.pct <= 100)) well.push("Semua budget masih dalam batas.");
    bu.filter((b) => b.state !== "ok").forEach((b) => watch.push(b.state === "over" ? `Budget ${b.label} terlampaui ${money(-b.left)}.` : `Budget ${b.label} hampir habis (${pct(b.pct, 0)}).`));
    if (st.count && st.net < 0) watch.push("Pengeluaran melebihi pemasukan bulan ini.");
    const row = (l, a, b, f = money, inv = false) => {
      const dd = a - b;
      return `<div class="cmp"><span>${l}</span><span>${f(a)}</span><span class="muted">${f(b)}</span><span class="${dd === 0 ? "" : dd > 0 !== inv ? "pos" : "neg"}">${dd > 0 ? "\u25B2" : dd < 0 ? "\u25BC" : "="}</span></div>`;
    };
    const html = `${monthNav(V.mk, "vMonth")}<div class="card"><div class="grid2 tight">${[["Income", money(st.income)], ["Expense", money(st.expense)], ["Savings", money(st.savings)], ["Debt payment", money(st.debtPayment)], ["Saving rate", st.savingRate == null ? "\u2014" : pct(st.savingRate)], ["Net worth change", d == null ? "\u2014" : (d >= 0 ? "+ " : "") + money(d)]].map(([l, v]) => `<div><div class="lbl">${l}</div><div class="val">${v}</div></div>`).join("")}</div></div>
  <div class="card"><div class="card-h"><h3>What went well</h3></div>${well.length ? well.map((x) => `<p class="insight good">${esc(x)}</p>`).join("") : '<p class="muted small">Belum ada pembanding yang cukup.</p>'}</div>
  <div class="card"><div class="card-h"><h3>Watch out</h3></div>${watch.length ? watch.map((x) => `<p class="insight warn">${esc(x)}</p>`).join("") : '<p class="muted small">Tidak ada hal yang perlu diperhatikan.</p>'}</div>
  <div class="card"><div class="card-h"><h3>Bulan ini vs bulan lalu</h3></div><div class="cmp head"><span></span><span>${MON3[+V.mk.slice(5) - 1]}</span><span>${MON3[+addMonths(V.mk, -1).slice(5) - 1]}</span><span></span></div>${row("Income", st.income, pv.income)}${row("Expense", st.expense, pv.expense, money, true)}${row("Sisa", st.net, pv.net)}${row("Saving rate", st.savingRate || 0, pv.savingRate || 0, (v) => pct(v, 0))}</div>`;
    return { title: "Monthly Review", html };
  }
  var Y = { y: +today().slice(0, 4) };
  function annualPage() {
    const ms = Array.from({ length: 12 }, (_, i) => monthStats(S, `${Y.y}-${String(i + 1).padStart(2, "0")}`)), ti = sum(ms, (m) => m.income), te = sum(ms, (m) => m.expense), h = netWorthHistory(S);
    const html = `<div class="monthnav"><button class="icon-btn" data-act="yMove" data-d="-1" aria-label="Tahun sebelumnya">\u2039</button><strong>${Y.y}</strong><button class="icon-btn" data-act="yMove" data-d="1" aria-label="Tahun berikutnya">\u203A</button></div>
  <div class="grid2 three"><div class="card stat"><div class="lbl">Income</div><div class="val pos">${money(ti)}</div></div><div class="card stat"><div class="lbl">Expense</div><div class="val neg">${money(te)}</div></div><div class="card stat"><div class="lbl">Saving rate</div><div class="val">${ti ? pct((ti - te) / ti * 100, 0) : "\u2014"}</div></div></div>
  <div class="card">${ti + te ? groupedBars(MON3, ms.map((m) => m.income), ms.map((m) => m.expense)) : '<p class="muted small">Belum ada transaksi di tahun ini.</p>'}</div>
  <div class="card"><div class="cmp head"><span>Bulan</span><span>Income</span><span>Expense</span><span>Sisa</span></div>${ms.map((m, i) => `<div class="cmp"><span>${MON3[i]}</span><span>${short(m.income)}</span><span>${short(m.expense)}</span><span class="${m.net >= 0 ? "pos" : "neg"}">${short(m.net)}</span></div>`).join("")}</div>`;
    return { title: "Tahunan", html };
  }
  var ACT3 = {
    rerender: () => {
    },
    rTab: (el, r) => {
      R.tab = el.dataset.v;
      r();
    },
    rMonth: (el, r) => {
      R.mk = addMonths(R.mk, +el.dataset.d);
      r();
    },
    cfRange: (el, r) => {
      C.range = el.dataset.v;
      r();
    },
    kMonth: (el, r) => {
      K.mk = addMonths(K.mk, +el.dataset.d);
      r();
    },
    kMode: (el, r) => {
      K.mode = el.dataset.v;
      r();
    },
    dayDetail: (el) => dayDetail(el.dataset.d),
    vMonth: (el, r) => {
      V.mk = addMonths(V.mk, +el.dataset.d);
      r();
    },
    yMove: (el, r) => {
      Y.y += +el.dataset.d;
      r();
    },
    setMode: async (el) => {
      await saveSettings({ mode: el.dataset.v });
    },
    addScn: () => scenarioSheet(),
    editScn: (el) => scenarioSheet(el.dataset.id),
    seedScn: () => seedScenarios()
  };

  // js/demo.js
  var rng = (seed) => () => {
    seed |= 0;
    seed = seed + 1831565813 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
  async function loadDemo() {
    const r = rng(11), cats = defaultCategories(), C2 = (n2, k = "expense") => cats.find((c) => c.name === n2 && c.kind === k).id, t0 = today(), mkNow = curMonth();
    const accounts = [["cash", "Cash", "cash", 5e5], ["bri", "BRI", "bank", 3e6], ["dana", "DANA", "ewallet", 3e5], ["tab", "Tabungan", "savings", 2e6], ["inv", "Investasi", "investment", 15e5]].map(([id, name, type, openingBalance]) => ({ id: "acc_" + id, name, type, openingBalance, note: "", createdAt: now() }));
    const tx2 = [];
    let n = 0;
    const add = (o) => {
      const date = o.date;
      if (date > t0) return;
      tx2.push({ id: "tx_demo_" + n++, sub: "", note: "", toAccountId: null, categoryId: null, goalId: null, liabilityId: null, createdAt: now(), updatedAt: now(), ...o });
    };
    for (const mk of [addMonths(mkNow, -2), addMonths(mkNow, -1), mkNow]) {
      const D = (d) => `${mk}-${String(d).padStart(2, "0")}`, cur = mk === mkNow;
      add({ type: "income", date: D(1), accountId: "acc_bri", categoryId: C2("Gaji", "income"), amount: 7e6, note: "Gaji bulanan" });
      add({ type: "expense", date: D(1), accountId: "acc_bri", categoryId: C2("Kebutuhan"), sub: "Tempat tinggal", amount: 1e6, note: "Kos" });
      add({ type: "transfer", date: D(2), accountId: "acc_bri", toAccountId: "acc_tab", amount: 1e6, goalId: "goal_ef", note: "Setor ke Dana Darurat" });
      add({ type: "transfer", date: D(3), accountId: "acc_bri", toAccountId: "acc_tab", amount: 5e5, goalId: "goal_lap", note: "Setor ke Laptop" });
      add({ type: "transfer", date: D(3), accountId: "acc_bri", toAccountId: "acc_inv", amount: 5e5, note: "Investasi bulanan" });
      add({ type: "transfer", date: D(4), accountId: "acc_bri", toAccountId: "acc_cash", amount: 4e5, note: "Tarik tunai" });
      add({ type: "transfer", date: D(4), accountId: "acc_bri", toAccountId: "acc_dana", amount: 4e5, note: "Isi DANA" });
      add({ type: "expense", date: D(5), accountId: "acc_bri", categoryId: C2("Keuangan"), sub: "Pembayaran utang", amount: 5e5, liabilityId: "lia_hp", note: "Bayar Cicilan HP" });
      add({ type: "expense", date: D(8), accountId: "acc_bri", categoryId: C2("Pengembangan Diri"), sub: "AI Tools", amount: 18e4, note: "Langganan AI" });
      add({ type: "expense", date: D(10), accountId: "acc_bri", categoryId: C2("Kebutuhan"), sub: "Internet", amount: 2e5, note: "Internet" });
      if (!cur) add({ type: "expense", date: D(15), accountId: "acc_bri", categoryId: C2("Pengembangan Diri"), sub: "Buku", amount: 12e4, note: "Buku referensi" });
      for (let d = 1; d <= daysInMonth(mk); d++) {
        if (r() < 0.75) add({ type: "expense", date: D(d), accountId: d % 2 ? "acc_dana" : "acc_cash", categoryId: C2("Kebutuhan"), sub: "Makan", amount: Math.round((15e3 + r() * 25e3) / 1e3) * 1e3, note: d % 2 ? "Makan malam" : "Makan siang" });
        if (d % 3 === 0) add({ type: "expense", date: D(d), accountId: "acc_cash", categoryId: C2("Kebutuhan"), sub: "Transportasi", amount: Math.round((12e3 + r() * 12e3) / 1e3) * 1e3, note: "Ojek / angkot" });
        if (d % 6 === 0) add({ type: "expense", date: D(d), accountId: "acc_dana", categoryId: C2("Gaya Hidup"), sub: "Kopi", amount: 28e3, note: "Kopi" });
        if (d === 12 || d === 24) add({ type: "expense", date: D(d), accountId: "acc_dana", categoryId: C2("Gaya Hidup"), sub: "Hiburan", amount: 75e3, note: "Nonton" });
      }
      if (cur) add({ type: "expense", date: D(6), accountId: "acc_dana", categoryId: C2("Gaya Hidup"), sub: "Hiburan", amount: 25e4, note: "Konser" });
    }
    const dl = /* @__PURE__ */ new Date();
    dl.setMonth(dl.getMonth() + 10);
    const lastRun = (day) => Number(t0.slice(8)) >= day ? mkNow : addMonths(mkNow, -1);
    const rec = (id, name, type, cat, sub, amount, acc, day) => ({ id: "rec_" + id, name, type, categoryId: cat, sub, amount, accountId: acc, day, active: true, lastRun: lastRun(day) });
    const data = {
      app: "ChemFinance",
      version: 1,
      profile: [{ id: "me", name: S.profile?.name || "Pengguna", currency: "IDR", monthlyIncome: 7e6, mandatoryExpense: 25e5, efMonths: 6, onboarded: true }],
      settings: [{ ...S.settings, demo: true, lastAccountId: "acc_bri" }],
      accounts,
      transactions: tx2,
      categories: cats,
      budgets: [["Kebutuhan", "Makan", 75e4], ["Kebutuhan", "Transportasi", 5e5], ["Kebutuhan", "Internet", 2e5], ["Gaya Hidup", "Hiburan", 3e5]].map(([c, s, a], i) => ({ id: "bud_" + i, categoryId: C2(c), sub: s, amount: a })),
      goals: [
        { id: "goal_ef", name: "Dana Darurat", target: 15e6, start: 3e6, deadline: "", priority: "high", monthly: 1e6, isEmergency: true, createdAt: now() },
        { id: "goal_lap", name: "Laptop", target: 1e7, start: 2e6, deadline: ymd(dl), priority: "medium", monthly: 1e6, createdAt: now() },
        { id: "goal_lib", name: "Liburan", target: 5e6, start: 5e5, deadline: "", priority: "low", monthly: 0, createdAt: now() }
      ],
      assets: [{ id: "ast_motor", name: "Motor", type: "Kendaraan", value: 15e6, updatedAt: now() }],
      liabilities: [{ id: "lia_hp", name: "Cicilan HP", type: "Cicilan", original: 6e6, remaining: 35e5, installment: 5e5, dueDay: 5, interest: 0, status: "aktif" }],
      recurring: [rec("gaji", "Gaji", "income", C2("Gaji", "income"), "", 7e6, "acc_bri", 1), rec("kos", "Kos", "expense", C2("Kebutuhan"), "Tempat tinggal", 1e6, "acc_bri", 1), rec("net", "Internet", "expense", C2("Kebutuhan"), "Internet", 2e5, "acc_bri", 10)],
      scenarios: [],
      snapshots: []
    };
    return importBackup(data);
  }

  // js/views-settings.js
  var sw = (act, on, label) => `<label class="switch"><input type="checkbox" data-act="${act}" ${on ? "checked" : ""} aria-label="${label}"><span></span></label>`;
  var when = (iso) => iso ? new Date(iso).toLocaleString("id-ID", { dateStyle: "medium", timeStyle: "short" }) : "Belum pernah";
  function settingsPage() {
    const st = S.settings, p = S.profile || {};
    const row = (t, d, right) => `<div class="row static"><div class="row-main"><div class="row-t">${t}</div>${d ? `<div class="row-s">${d}</div>` : ""}</div>${right || ""}</div>`;
    const btn = (act, t, d) => `<button class="row" data-act="${act}"><div class="row-main"><div class="row-t">${t}</div>${d ? `<div class="row-s">${d}</div>` : ""}</div><span class="chev">\u203A</span></button>`;
    const nav = (k, t, d) => `<button class="row" data-nav="${k}"><div class="row-main"><div class="row-t">${t}</div>${d ? `<div class="row-s">${d}</div>` : ""}</div><span class="chev">\u203A</span></button>`;
    const html = `
  <div class="card"><div class="card-h"><h3>Profil</h3></div><div class="list flush">${btn("editProfile", esc(p.name || "Pengguna"), "Target income " + money(p.monthlyIncome || 0))}${row("Mata uang", "IDR \xB7 Rupiah (format Rp 1.000.000)")}</div></div>
  <div class="card"><div class="card-h"><h3>Tampilan</h3></div><div class="seg" role="group" aria-label="Tema">${[["light", "Terang"], ["dark", "Gelap"], ["system", "Sistem"]].map(([v, l]) => `<button class="${st.theme === v ? "on" : ""}" data-act="setTheme" data-v="${v}" aria-pressed="${st.theme === v}">${l}</button>`).join("")}</div>
    <div class="list flush">${row("Sembunyikan saldo", "Nominal ditampilkan sebagai Rp \u2022\u2022\u2022\u2022\u2022\u2022", sw("toggleHide", st.hide, "Sembunyikan saldo"))}</div></div>
  <div class="card"><div class="card-h"><h3>Keamanan</h3></div><div class="list flush">${btn("setPin", st.pinHash ? "Ubah atau hapus PIN" : "Aktifkan App Lock (PIN)", st.pinHash ? "PIN aktif \u2014 disimpan sebagai hash" : "PIN 4\u20136 digit, disimpan lokal sebagai hash")}${btn("enableNotif", "Pengingat", st.notify ? "Aktif \u2014 tampil saat aplikasi dibuka" : "Aktifkan notifikasi saat aplikasi dibuka")}</div><p class="hint">PIN hanya mengunci tampilan di perangkat ini; bukan enkripsi data. Notifikasi tidak berjalan di latar belakang karena tidak ada server.</p></div>
  <div class="card"><div class="card-h"><h3>Data</h3></div><div class="list flush">${nav("categories", "Kategori", "Tambah, ubah, hapus kategori")}${nav("accounts", "Rekening", "Kelola rekening")}${nav("budget", "Budget", "Atur budget bulanan")}${nav("backup", "Backup, Import, Export", "JSON dan CSV")}${st.demo ? btn("clearDemo", "Hapus Data Demo", "Kembali ke data kosong (profil dipertahankan)") : btn("loadDemo", "Load Demo Data", "Isi contoh data realistis \u2014 bisa dihapus kapan saja")}${btn("resetAll", "Reset semua data", "Menghapus seluruh data di perangkat ini")}</div></div>
  <div class="card"><div class="list flush">${nav("about", "Tentang Chem Studio", "ChemFinance v1.0")}</div></div>`;
    return { title: "Pengaturan", html };
  }
  function categoriesPage() {
    const block = (kind, title) => `<div class="card"><div class="card-h"><h3>${title}</h3></div><div class="list flush">${S.categories.filter((c) => c.kind === kind).map((c) => `<button class="row" data-act="editCat" data-id="${c.id}"><div class="row-main"><div class="row-t">${esc(c.name)}</div>${c.subs.length ? `<div class="row-s">${esc(c.subs.join(", "))}</div>` : ""}</div><span class="chev">\u203A</span></button>`).join("")}</div></div>`;
    return { title: "Kategori", html: block("expense", "Pengeluaran") + block("income", "Pemasukan") + '<button class="btn primary block" data-act="addCat">Tambah kategori</button>' };
  }
  function categorySheet(id = null) {
    const c = id ? S.categories.find((x) => x.id === id) : null;
    formSheet({
      title: c ? "Edit kategori" : "Tambah kategori",
      fields: [{ id: "name", label: "Nama kategori", type: "text", value: c?.name }, ...c ? [] : [{ id: "kind", label: "Jenis", type: "select", options: [["expense", "Pengeluaran"], ["income", "Pemasukan"]], value: "expense" }], { id: "subs", label: "Subkategori (pisahkan dengan koma)", type: "textarea", value: c?.subs.join(", "), hint: "Hanya untuk kategori pengeluaran." }],
      onSubmit: async (v) => {
        if (!v.name) return "Nama kategori wajib diisi.";
        const kind = c?.kind || v.kind;
        if (S.categories.some((x) => x.id !== id && x.kind === kind && x.name.toLowerCase() === v.name.toLowerCase())) return "Nama kategori sudah dipakai.";
        const subs = kind === "income" ? [] : [...new Set(v.subs.split(",").map((s) => s.trim()).filter(Boolean))];
        await save("categories", { ...c || {}, id: id || uid("cat"), name: v.name, kind, subs });
        toast("Kategori disimpan.");
      },
      onDelete: c ? async () => (await deleteCategory(id)).error : null
    });
  }
  function backupPage() {
    const st = S.settings, dirty = st.lastChange && (!st.lastBackup || st.lastChange > st.lastBackup);
    const count = (k) => S[k].length;
    const html = `<div class="card"><div class="item-h"><span>Backup terakhir</span><strong>${when(st.lastBackup)}</strong></div><div class="item-h"><span>Data terakhir diubah</span><strong>${when(st.lastChange)}</strong></div>
    ${dirty ? '<p class="insight warn">Ada perubahan sejak backup terakhir. Simpan backup agar data aman saat ganti HP atau browser.</p>' : ""}<p class="small muted">${count("transactions")} transaksi \xB7 ${count("accounts")} rekening \xB7 ${count("goals")} target</p></div>
  <div class="card"><div class="card-h"><h3>Export</h3></div><div class="btn-row"><button class="btn primary" data-act="expJSON">Export JSON (backup lengkap)</button><button class="btn ghost" data-act="expCSV">Export CSV (transaksi)</button></div></div>
  <div class="card"><div class="card-h"><h3>Restore</h3></div><p class="small muted">Import file backup JSON. Data saat ini akan diganti.</p><label class="btn ghost block filebtn">Pilih file backup<input type="file" id="imp" accept=".json,application/json" hidden></label><div class="form-error" id="imperr" role="alert"></div></div>
  <div class="card"><div class="card-h"><h3>Zona berbahaya</h3></div><button class="btn danger-o block" data-act="resetAll">Reset semua data</button></div>
  <p class="hint">Data tersimpan hanya di perangkat ini (IndexedDB). Tidak dikirim ke server mana pun.</p>`;
    return { title: "Backup", html, mount: (root) => {
      root.querySelector("#imp").onchange = async (e) => {
        const f = e.target.files[0];
        if (!f) return;
        const err = (m) => root.querySelector("#imperr").textContent = m;
        let d;
        try {
          d = JSON.parse(await f.text());
        } catch {
          return err("Berkas bukan JSON yang valid.");
        }
        const bad = validateBackup(d);
        if (bad) return err(bad);
        err("");
        if (await confirmBox({ title: "Restore data?", message: `Backup berisi ${d.transactions.length} transaksi. Data saat ini akan diganti.`, okText: "Restore", danger: true })) {
          const r = await importBackup(d);
          toast(r.error || "Data berhasil dipulihkan.");
        }
        e.target.value = "";
      };
    } };
  }
  var download = (name, text, type) => {
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([text], { type }));
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4e3);
  };
  var stamp = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  function aboutPage() {
    return { title: "Tentang", html: `<div class="card hero"><div class="big sm">ChemFinance</div><div class="muted">by Chem Studio</div><p class="tagline">Built by Knowledge. Forged by Experience.</p></div>
  <div class="card"><p>ChemFinance membantu mengetahui ke mana uang pergi, bagaimana kondisi keuangan saat ini, dan apakah bergerak menuju target Anda.</p><p class="small muted">Bagian dari ekosistem Chem Studio: ChemFinance, ChemTrack, ChemMetrics, Chemorium. Aplikasi ini berdiri sendiri dan tidak bergantung pada aplikasi lain.</p></div>
  <div class="card"><div class="card-h"><h3>Privasi</h3></div><p class="small">Data keuangan tersimpan hanya di perangkat Anda. Tidak ada server, analytics, atau koneksi rekening bank. ChemFinance tidak pernah meminta password atau PIN bank.</p><p class="small muted">Skor, insight, dan mode adalah alat bantu memahami kondisi keuangan, bukan nasihat keuangan profesional.</p></div><p class="center muted small">Versi 1.0</p>` };
  }
  var ACT4 = {
    editProfile: () => formSheet({ title: "Profil", fields: [{ id: "name", label: "Nama", type: "text", value: S.profile?.name }, { id: "inc", label: "Target pemasukan bulanan (Rp)", type: "money", value: S.profile?.monthlyIncome }], onSubmit: async (v) => {
      if (!v.name) return "Nama wajib diisi.";
      await saveProfile({ name: v.name, monthlyIncome: v.inc || 0 });
      toast("Profil disimpan.");
    } }),
    setTheme: (el) => saveSettings({ theme: el.dataset.v }),
    toggleHide: (el) => saveSettings({ hide: el.checked ?? !S.settings.hide }),
    setPin: () => {
      const has = !!S.settings.pinHash;
      formSheet({
        title: has ? "Ubah / hapus PIN" : "Aktifkan PIN",
        intro: has ? "Masukkan PIN lama. Kosongkan PIN baru untuk menghapus PIN." : "Gunakan 4\u20136 digit angka.",
        fields: [...has ? [{ id: "cur", label: "PIN lama", type: "password", max: 6 }] : [], { id: "pin", label: has ? "PIN baru" : "PIN", type: "password", max: 6 }, { id: "pin2", label: "Ulangi PIN", type: "password", max: 6 }],
        onSubmit: async (v) => {
          if (has && await hashPin(v.cur) !== S.settings.pinHash) return "PIN lama salah.";
          if (has && !v.pin) {
            await saveSettings({ pinHash: null });
            toast("PIN dihapus.");
            return;
          }
          if (!/^\d{4,6}$/.test(v.pin)) return "PIN harus 4\u20136 digit angka.";
          if (v.pin !== v.pin2) return "Ulangi PIN tidak sama.";
          await saveSettings({ pinHash: await hashPin(v.pin) });
          toast("PIN aktif.");
        }
      });
    },
    enableNotif: async () => {
      if (!("Notification" in window)) return toast("Browser ini tidak mendukung notifikasi.");
      const r = await Notification.requestPermission();
      if (r === "granted") {
        await saveSettings({ notify: true });
        toast("Pengingat aktif. Muncul saat aplikasi dibuka.");
      } else toast("Izin notifikasi ditolak. Pengingat tetap tampil di dalam aplikasi.");
    },
    addCat: () => categorySheet(),
    editCat: (el) => categorySheet(el.dataset.id),
    expJSON: async () => {
      download(`chemfinance-backup-${stamp()}.json`, exportJSON(), "application/json");
      await markBackup();
      toast("Backup JSON diunduh.");
    },
    expCSV: () => {
      download(`chemfinance-transaksi-${stamp()}.csv`, exportCSV(), "text/csv");
      toast("CSV diunduh.");
    },
    loadDemo: async () => {
      if ((S.transactions.length || S.accounts.length) && !await confirmBox({ title: "Load demo data?", message: "Data Anda saat ini akan diganti data demo. Buat backup dulu jika perlu.", okText: "Ganti dengan demo", danger: true })) return;
      await loadDemo();
      toast("Data demo dimuat. Hapus kapan saja di Pengaturan.");
      window.dispatchEvent(new CustomEvent("cf-nav", { detail: "home" }));
    },
    clearDemo: async () => {
      if (await confirmBox({ title: "Hapus data demo?", message: "Seluruh data demo dihapus. Profil dan pengaturan tema/PIN dipertahankan.", okText: "Hapus", danger: true })) {
        await resetAll({ keepProfile: true });
        toast("Data demo dihapus.");
      }
    },
    resetAll: async () => {
      if (!await confirmBox({ title: "Reset semua data?", message: "Semua transaksi, rekening, target, dan pengaturan akan dihapus dari perangkat ini.", okText: "Lanjut", danger: true })) return;
      if (!await confirmBox({ title: "Yakin? Tidak bisa dibatalkan", message: "Ini konfirmasi terakhir. Pastikan Anda sudah menyimpan backup.", okText: "Hapus semua", danger: true })) return;
      await resetAll();
      try {
        history.replaceState(null, "", "#/home");
      } catch {
      }
      location.reload();
    }
  };

  // js/app.js
  var ROUTES = {
    home,
    tx: txPage,
    budget: budgetPage,
    goals: goalsPage,
    more: morePage,
    accounts: accountsPage,
    assets: assetsPage,
    debts: debtsPage,
    recurring: recurringPage,
    emergency: emergencyPage,
    reports: reportsPage,
    cashflow: cashflowPage,
    calendar: calendarPage,
    scenarios: scenariosPage,
    review: reviewPage,
    annual: annualPage,
    settings: settingsPage,
    categories: categoriesPage,
    backup: backupPage,
    about: aboutPage
  };
  var TAB = { home: "home", tx: "tx", budget: "budget", goals: "goals", emergency: "goals" };
  var PARENT = { categories: "settings", about: "settings", emergency: "goals" };
  var FAB_ON = ["home", "tx"];
  var ICONS = { home: "M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z", tx: "M4 6h16M4 12h16M4 18h10", budget: "M12 3a9 9 0 1 0 9 9h-9z M15 3.5A9 9 0 0 1 20.5 9H15z", goals: "M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8z", more: "M5 12h.01M12 12h.01M19 12h.01" };
  var LABEL = { home: "Home", tx: "Transaksi", budget: "Budget", goals: "Goals", more: "Lainnya" };
  var ACT5 = {
    ...ACT,
    ...ACT2,
    ...ACT3,
    ...ACT4,
    addTxOn: (el) => openTxSheet(null, { date: el.dataset.d }),
    quick: (el) => openTxSheet(null, { type: el.dataset.t }),
    addTxFab: () => openTxSheet(),
    toggleHideTop: () => saveSettings({ hide: !S.settings.hide }),
    back: () => go(PARENT[route()] || "more")
  };
  var lastRoute = null;
  var current = "home";
  var fromHash = () => {
    const r = (location.hash || "").replace(/^#\//, "") || "home";
    return ROUTES[r] ? r : "home";
  };
  var route = () => current;
  function go(r) {
    if (!ROUTES[r]) r = "home";
    closeSheet();
    current = r;
    try {
      if (location.hash !== "#/" + r) history.replaceState(null, "", "#/" + r);
    } catch {
    }
    render();
  }
  function applyTheme() {
    const t = S.settings.theme, root = document.documentElement;
    if (t === "system") root.removeAttribute("data-theme");
    else root.setAttribute("data-theme", t);
    const dark = t === "dark" || t === "system" && matchMedia("(prefers-color-scheme: dark)").matches;
    $('meta[name="theme-color"]').content = dark ? "#0f1a2b" : "#1d4f9f";
  }
  function render() {
    if (!S.settings) return;
    applyTheme();
    const r = route(), v = ROUTES[r](), same = r === lastRoute, y = same ? window.scrollY : 0, isTab = r in TAB || r === "more", tab = TAB[r] || "more";
    document.title = `${v.title} \xB7 ChemFinance`;
    $("#bar").innerHTML = `${isTab ? `<div class="brand"><svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="7" fill="currentColor"/><path d="M8 21l5-6 4 3 7-9" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="8" cy="21" r="2" fill="#fff"/><circle cx="24" cy="9" r="2" fill="#fff"/></svg><div><div class="brand-t">ChemFinance</div><div class="brand-s">Personal Finance OS \xB7 Chem Studio</div></div></div>` : `<button class="icon-btn" data-act="back" aria-label="Kembali">\u2039</button><h1 class="page-t">${esc(v.title)}</h1>`}
    <button class="icon-btn" data-act="toggleHideTop" aria-label="${S.settings.hide ? "Tampilkan saldo" : "Sembunyikan saldo"}" aria-pressed="${S.settings.hide}">${S.settings.hide ? "\u{1F648}" : "\u{1F441}"}</button>`;
    $("#view").innerHTML = (isTab && r !== "home" ? `<h1 class="page-t main">${esc(v.title)}</h1>` : "") + (r === "home" ? quickRow() : "") + v.html;
    v.mount?.($("#view"));
    $("#nav").innerHTML = Object.keys(LABEL).map((k) => `<a href="#/${k}" class="nav-i ${k === tab ? "on" : ""}" ${k === tab ? 'aria-current="page"' : ""}><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${ICONS[k]}"/></svg><span>${LABEL[k]}</span></a>`).join("");
    $("#fab").hidden = !FAB_ON.includes(r);
    lastRoute = r;
    window.scrollTo(0, y);
  }
  var quickRow = () => `<div class="chips scroll qa" aria-label="Aksi cepat"><button class="chip" data-act="quick" data-t="income">+ Pemasukan</button><button class="chip" data-act="quick" data-t="expense">+ Pengeluaran</button><button class="chip" data-act="quick" data-t="transfer">+ Transfer</button><button class="chip" data-act="addDebt">+ Utang</button><button class="chip" data-act="addGoal">+ Tabungan</button><button class="chip" data-act="addAsset">+ Aset</button></div>`;
  var hiddenAt = 0;
  var unlocked = false;
  function lockScreen() {
    return new Promise((resolve) => {
      unlocked = false;
      let pin = "";
      const d = document.createElement("div");
      d.className = "lock";
      d.setAttribute("role", "dialog");
      d.setAttribute("aria-label", "Kunci aplikasi");
      d.innerHTML = `<div class="lock-in"><div class="brand-t">ChemFinance</div><p class="muted">Masukkan PIN</p><div class="dots" id="pd" aria-live="polite"></div><div class="form-error" id="pe" role="alert"></div><div class="pad">${[1, 2, 3, 4, 5, 6, 7, 8, 9, "", 0, "\u232B"].map((k) => `<button ${k === "" ? 'disabled style="visibility:hidden"' : ""} data-k="${k}" aria-label="${k === "\u232B" ? "Hapus" : k}">${k}</button>`).join("")}</div></div>`;
      document.body.appendChild(d);
      const paint = () => $("#pd", d).textContent = "\u25CF".repeat(pin.length) + "\u25CB".repeat(Math.max(0, 4 - pin.length));
      paint();
      d.onclick = async (e) => {
        const b = e.target.closest("[data-k]");
        if (!b) return;
        const k = b.dataset.k;
        $("#pe", d).textContent = "";
        if (k === "\u232B") pin = pin.slice(0, -1);
        else if (pin.length < 6) pin += k;
        paint();
        if (pin.length >= 4 && await hashPin(pin) === S.settings.pinHash) {
          unlocked = true;
          d.remove();
          resolve();
        } else if (pin.length === 6) {
          $("#pe", d).textContent = "PIN salah.";
          pin = "";
          paint();
        }
      };
    });
  }
  function onboarding() {
    return new Promise((resolve) => {
      const o = { name: "", income: 0, mandatory: 0, efMonths: 6, accName: "Rekening Utama", accType: "bank", balance: 0 };
      let step = 0;
      const steps = [
        { t: "Siapa nama Anda?", h: () => `<div class="field"><label for="o_name">Nama</label><input id="o_name" maxlength="40" autocomplete="given-name" value="${esc(o.name)}"></div><p class="hint">Data keuangan tersimpan hanya di perangkat ini. Tidak ada login dan tidak ada server.</p>`, rd: (r) => o.name = $("#o_name", r).value.trim(), ok: () => o.name ? "" : "Nama wajib diisi." },
        { t: "Mata uang", h: () => '<div class="field"><label for="o_cur">Mata uang</label><select id="o_cur" disabled><option>IDR \xB7 Rupiah</option></select></div><p class="hint">Versi pertama fokus pada Rupiah (Rp 1.000.000).</p>', rd: () => {
        }, ok: () => "" },
        { t: "Pendapatan bulanan", h: () => `<div class="field"><label for="o_inc">Perkiraan pendapatan per bulan (Rp)</label><input id="o_inc" data-money inputmode="numeric" placeholder="0" value="${o.income ? dots(o.income) : ""}"></div><p class="hint">Dipakai sebagai target income. Boleh dikosongkan dan diubah nanti.</p>`, rd: (r) => o.income = parseAmount($("#o_inc", r).value), ok: () => "" },
        { t: "Pengeluaran wajib", h: () => `<div class="field"><label for="o_man">Pengeluaran wajib per bulan (Rp)</label><input id="o_man" data-money inputmode="numeric" placeholder="0" value="${o.mandatory ? dots(o.mandatory) : ""}"></div><p class="hint">Kos, makan, transportasi, tagihan, cicilan.</p>`, rd: (r) => o.mandatory = parseAmount($("#o_man", r).value), ok: () => "" },
        { t: "Target dana darurat", h: () => `<div class="field"><label for="o_ef">Target jumlah bulan</label><input id="o_ef" type="number" min="1" max="36" step="1" value="${o.efMonths}"></div><p class="hint">Target = pengeluaran wajib \xD7 jumlah bulan = ${money(o.mandatory * o.efMonths)}</p>`, rd: (r) => o.efMonths = Math.max(1, Math.round(Number($("#o_ef", r).value) || 6)), ok: () => "" },
        { t: "Saldo awal", h: () => `<div class="field"><label for="o_an">Nama rekening utama</label><input id="o_an" maxlength="30" value="${esc(o.accName)}"></div><div class="field"><label for="o_at">Jenis</label><select id="o_at">${Object.entries(ACCOUNT_TYPES).map(([k, l]) => `<option value="${k}" ${k === o.accType ? "selected" : ""}>${l}</option>`).join("")}</select></div><div class="field"><label for="o_bal">Saldo awal (Rp)</label><input id="o_bal" data-money inputmode="numeric" placeholder="0" value="${o.balance ? dots(o.balance) : ""}"></div>`, rd: (r) => {
          o.accName = $("#o_an", r).value.trim() || "Rekening Utama";
          o.accType = $("#o_at", r).value;
          o.balance = parseAmount($("#o_bal", r).value);
        }, ok: () => "" }
      ];
      const d = document.createElement("div");
      d.className = "onb";
      document.body.appendChild(d);
      const draw = (done = false) => {
        if (done) {
          d.innerHTML = `<div class="onb-in"><div class="big sm">Your financial system is ready.</div><p class="muted">Mulai dengan mencatat transaksi pertama, atau lihat contoh dengan data demo.</p><div class="btn-row"><button class="btn primary" id="go">Mulai</button><button class="btn ghost" id="demo">Load Demo Data</button></div></div>`;
          $("#go", d).onclick = async () => {
            await completeOnboarding(o);
            d.remove();
            resolve();
          };
          $("#demo", d).onclick = async () => {
            await completeOnboarding(o);
            await loadDemo();
            d.remove();
            resolve();
          };
          return;
        }
        const s = steps[step];
        d.innerHTML = `<div class="onb-in"><div class="muted small">Langkah ${step + 1} dari ${steps.length}</div><div class="bar"><div class="bar-fill ok" style="width:${(step + 1) / steps.length * 100}%"></div></div><h1>${s.t}</h1><div class="form-error" id="oe" role="alert"></div>${s.h()}<div class="btn-row">${step ? '<button class="btn ghost" id="bk">Kembali</button>' : ""}<button class="btn primary" id="nx">${step === steps.length - 1 ? "Selesai" : "Lanjut"}</button></div></div>`;
        $("#nx", d).onclick = () => {
          s.rd(d);
          const e = s.ok();
          if (e) {
            $("#oe", d).textContent = e;
            return;
          }
          if (step === steps.length - 1) draw(true);
          else {
            step++;
            draw();
          }
        };
        if (step) $("#bk", d).onclick = () => {
          s.rd(d);
          step--;
          draw();
        };
        d.querySelector("input:not([disabled])")?.focus();
      };
      draw();
    });
  }
  async function notifyOnOpen() {
    if (!S.settings.notify || !("Notification" in window) || Notification.permission !== "granted" || localStorage.getItem("cf_notified") === today()) return;
    const rem = reminders(S).filter((r) => r.days <= 3);
    if (!rem.length) return;
    localStorage.setItem("cf_notified", today());
    try {
      const reg = await navigator.serviceWorker.ready;
      reg.showNotification("ChemFinance", { body: rem.map((r) => r.text).join("\n"), icon: "./icons/icon-192.png", tag: "cf-reminder" });
    } catch {
    }
  }
  async function start() {
    try {
      await init();
    } catch (e) {
      $("#splash").innerHTML = '<div class="lock-in"><strong>Penyimpanan lokal tidak tersedia.</strong><p class="muted">Buka ChemFinance di Chrome biasa (bukan mode samaran) lalu muat ulang.</p></div>';
      return;
    }
    $("#splash").remove();
    bindMoneyInputs();
    onChange(render);
    applyTheme();
    document.addEventListener("click", (e) => {
      const n = e.target.closest("[data-nav]");
      if (n) {
        go(n.dataset.nav);
        return;
      }
      const l = e.target.closest("a.nav-i");
      if (l) {
        e.preventDefault();
        go(l.getAttribute("href").slice(2));
        return;
      }
      const a = e.target.closest("[data-act]");
      if (a && ACT5[a.dataset.act]) ACT5[a.dataset.act](a, render);
    });
    $("#fab").onclick = () => openTxSheet();
    ACT3.rerender = render;
    addEventListener("hashchange", () => {
      closeSheet();
      current = fromHash();
      render();
    });
    current = fromHash();
    addEventListener("cf-nav", (e) => go(e.detail));
    addEventListener("keydown", (e) => {
      if (e.key === "Escape") closeSheet();
    });
    document.addEventListener("visibilitychange", async () => {
      if (document.hidden) {
        hiddenAt = Date.now();
        return;
      }
      if (S.settings.pinHash && hiddenAt && Date.now() - hiddenAt > 6e4) await lockScreen();
      await runRecurring();
      render();
    });
    if (S.settings.pinHash) await lockScreen();
    if (!S.profile?.onboarded) await onboarding();
    render();
    notifyOnOpen();
    if (isTemporary()) setTimeout(() => toast("Penyimpanan permanen diblokir di sini. Data hanya sementara \u2014 gunakan Export JSON atau buka file di Chrome.", 6e3), 600);
    try {
      if ("serviceWorker" in navigator) navigator.serviceWorker.register("./service-worker.js").catch(() => {
      });
    } catch {
    }
  }
  start();
})();
